package app.yoru.mobile;

import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.select.Elements;
import org.json.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;
import java.io.IOException;

/** Catalog and stream adapters for sources that publish their own episode playlists. */
public final class NativeSources {
    private final ApiRepository api;
    public NativeSources(ApiRepository repository){api=repository;}
    private static String absolute(String base,String value){try{if(value==null||value.trim().isEmpty())return "";return ApiRepository.safeUrl(new URL(new URL(base),value.replace(" ","%20")).toString());}catch(Exception e){return "";}}
    public Anime.Page catalog(String source,String search,int page)throws Exception{
        String base=source.equals("sameband")?"https://sameband.studio":"https://amd.online";String html;
        if(search==null||search.trim().isEmpty()){String path=source.equals("sameband")?(page==1?"/anime/":"/anime/page/"+page+"/"):(page==1?"/":"/page/"+page+"/");html=api.document(base+path);}
        else{String body="do=search&subaction=search&full_search=0&result_from=1&search_start="+page+"&story="+URLEncoder.encode(search,"UTF-8");html=api.formPage(base+"/index.php?do=search",body);}
        Document doc=Jsoup.parse(html,base);Anime.Page result=new Anime.Page();result.page=page;LinkedHashMap<String,Anime> items=new LinkedHashMap<>();
        if(source.equals("sameband")){
            for(Element box:doc.select(".poster[title]")){Element a=box.selectFirst("a.image[href],a[href*=/anime/]");if(a==null)continue;String url=absolute(base,a.attr("href"));Matcher m=Pattern.compile("/anime/(\\d+)[^/]*\\.html").matcher(url);if(!m.find())continue;Anime row=new Anime();row.source=source;row.id=m.group(1);row.alias=url;row.title=box.attr("title").trim();Element img=box.selectFirst("img[src],img[data-src]");if(img!=null)row.poster=absolute(base,img.hasAttr("src")?img.attr("src"):img.attr("data-src"));row.type="Аниме";row.status="published";if(!row.title.isEmpty())items.put(row.key(),api.remember(row));}
        }else{
            for(Element box:doc.select(".grid-item,.poster")){Element a=box.selectFirst("a.poster__link[href]");if(a==null)continue;String url=absolute(base,a.attr("href"));Matcher m=Pattern.compile("/(\\d+)[^/]*\\.html").matcher(url);if(!m.find())continue;Element title=box.selectFirst(".poster__title");String text=title==null?a.text():title.text();if(text.trim().isEmpty())continue;Anime row=new Anime();row.source=source;row.id=m.group(1);row.alias=url;row.title=text.trim();row.type="Аниме";row.status="published";Element img=box.selectFirst("img[src],img[data-src]");if(img!=null)row.poster=absolute(base,img.hasAttr("src")?img.attr("src"):img.attr("data-src"));items.put(row.key(),api.remember(row));}
        }
        result.items.addAll(items.values());for(Element a:doc.select(".navigation a[href],.pagination a[href],.nav-next a[href]")){String href=a.attr("href");Matcher p=Pattern.compile("/page/(\\d+)").matcher(href);if(p.find()&&Integer.parseInt(p.group(1))>page)result.more=true;if(a.attr("rel").equals("next"))result.more=true;}
        if(result.items.isEmpty()&&!doc.text().toLowerCase(Locale.ROOT).contains("найден"))throw new IOException("Источник временно изменил страницу. Попробуйте позже.");return result;
    }
    public Anime details(Anime base,boolean episodes)throws Exception{
        String host=base.source.equals("sameband")?"https://sameband.studio":"https://amd.online";
        String url=base.alias.startsWith("https://")?base.alias:absolute(host,base.alias);
        if(url.isEmpty()||!new URL(url).getHost().equals(new URL(host).getHost()))throw new IOException("Откройте аниме из каталога источника");Document doc=Jsoup.parse(api.document(url),url);Anime a=Anime.from(base.json());a.alias=url;
        Element title=doc.selectFirst("h1");if(title!=null)a.title=title.text();Element description=doc.selectFirst(base.source.equals("sameband")?".limiter":".page__text,.pmovie__description,.full-text,.fdesc");if(description!=null)a.description=description.text();Element picture=doc.selectFirst(base.source.equals("sameband")?".image > img[src]":".pmovie__poster img,.page__poster img,.poster__img img");if(picture!=null)a.poster=absolute(url,picture.attr("src"));
        String warnings=doc.select(".player-blocked,.alert-danger").text();if(warnings.contains("правообладател")){a.blocked=true;return a;}
        if(episodes&&base.source.equals("sameband")){
            Element iframe=doc.selectFirst(".player iframe[src],iframe[src*=/v/play/],iframe[src*=/pl/]");if(iframe==null)throw new IOException("Список серий временно недоступен");String player=absolute(url,iframe.attr("src"));String body=api.document(player);Matcher list=Pattern.compile("file\\s*:\\s*[\"']([^\"']+)[\"']").matcher(body);if(!list.find())throw new IOException("Список серий временно недоступен");String playlist=absolute(player,list.group(1));JSONArray rows=new JSONArray(api.document(playlist));for(int i=0;i<rows.length();i++){JSONObject r=rows.optJSONObject(i);if(r==null)continue;Anime.Episode ep=new Anime.Episode();ep.id=a.id+"-"+(i+1);ep.number=i+1;ep.name="";Matcher links=Pattern.compile("\\[(\\d+)p\\]([^\\[]+)").matcher(r.optString("file"));while(links.find()){String link=links.group(2).trim().replaceAll(",$","");String media=absolute(host,link);if(!media.isEmpty())ep.streams.put(Integer.parseInt(links.group(1)),media);}if(!ep.streams.isEmpty())a.episodeList.add(ep);}
        }else if(episodes){
            TreeMap<Double,Anime.Episode> rows=new TreeMap<>();for(Element e:doc.select("[data-vid][data-vlnk]")){double number;try{number=Double.parseDouble(e.attr("data-vid"));}catch(Exception bad){continue;}String vod=absolute(host,e.attr("data-vlnk"));if(number<1||vod.isEmpty()||!vod.contains("/vod/"))continue;if(rows.containsKey(number))continue;Anime.Episode ep=new Anime.Episode();ep.id=e.attr("data-vid");ep.number=number;ep.name="";ep.lazy="animedia";ep.resolverUrl=vod;rows.put(number,ep);}a.episodeList.addAll(rows.values());
        }
        if(episodes){a.episodes=a.episodeList.size();if(a.episodes==0)throw new IOException("У источника пока нет доступных серий");}return api.remember(a);
    }
    public void loadEpisode(Anime.Episode ep)throws Exception{
        if(!ep.lazy.equals("animedia")||!ep.streams.isEmpty())return;String page=api.document(ep.resolverUrl);Matcher file=Pattern.compile("file\\s*:\\s*[\"']([^\"']+)[\"']").matcher(page);if(!file.find())throw new IOException("Видеопоток пока недоступен");String url=absolute(ep.resolverUrl,file.group(1));if(url.isEmpty())throw new IOException("Видеопоток пока недоступен");String manifest=api.document(url);if(!manifest.trim().startsWith("#EXTM3U"))throw new IOException("Источник не передал видеопоток");String[] lines=manifest.split("\\r?\\n");int height=0;for(String l:lines){l=l.trim();if(l.startsWith("#EXT-X-STREAM-INF")){Matcher m=Pattern.compile("RESOLUTION=\\d+x(\\d+)").matcher(l);height=m.find()?Integer.parseInt(m.group(1)):0;}else if(!l.isEmpty()&&!l.startsWith("#")&&height>0){ep.streams.put(height,absolute(url,l));height=0;}}if(ep.streams.isEmpty())ep.streams.put(0,url);
    }
}
