package app.yoru.mobile;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class YoruApp extends Application {
    public static YoruApp instance;
    public final ExecutorService io=Executors.newFixedThreadPool(3);
    public final Handler main=new Handler(Looper.getMainLooper());
    public SecureStore store;
    public ApiRepository api;
    public ImageLoader images;
    public boolean original;
    public TrafficMeter traffic;
    public MediaCache mediaCache;
    private DownloadHub downloads;
    public volatile int activePlayers;
    public synchronized DownloadHub downloads(){if(downloads==null)downloads=new DownloadHub(this,mediaCache);return downloads;}
    public boolean savingMobile(){return store.dataSaver()&&traffic.mobile();}
    public boolean autoNextAllowed(){return store.autoNext()&&!savingMobile();}
    @Override public void onCreate(){super.onCreate();instance=this;original=AppSecurity.original(this);WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);store=new SecureStore(this);traffic=new TrafficMeter(this,store);mediaCache=new MediaCache(this);api=new ApiRepository(this);images=new ImageLoader(this);}
    public static YoruApp app(){return instance;}
}
