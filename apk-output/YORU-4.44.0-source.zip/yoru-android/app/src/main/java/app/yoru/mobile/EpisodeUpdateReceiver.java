package app.yoru.mobile;

import android.Manifest;
import android.app.*;
import android.app.job.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.net.*;
import android.os.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.*;

public final class EpisodeUpdateReceiver extends BroadcastReceiver {
    private static final String ACTION="app.yoru.mobile.UPDATE_CHECK";
    private static final int ALARM_REQ=2301, JOB_PERIODIC=2302, JOB_NOW=2303;
    private static final long PERIOD=15L*60L*1000L, QUICK=75L*1000L, MAX_BUDGET=70L*1000L;
    private static final AtomicBoolean RUNNING=new AtomicBoolean(false);

    public static void schedule(Context context){schedule(context,PERIOD);}
    public static void schedule(Context context,long delay){Context c=context.getApplicationContext();scheduleAlarm(c,delay);schedulePeriodicJob(c);}
    public static void checkSoon(Context context){Context c=context.getApplicationContext();scheduleAlarm(c,QUICK);scheduleOneShotJob(c,QUICK);}
    public static void checkNow(Context context){Context c=context.getApplicationContext();schedule(c,PERIOD);scheduleOneShotJob(c,0);try{c.sendBroadcast(new Intent(c,EpisodeUpdateReceiver.class).setAction(ACTION));}catch(Exception ignored){}}

    private static void scheduleAlarm(Context context,long delay){try{AlarmManager alarm=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);if(alarm==null)return;Intent intent=new Intent(context,EpisodeUpdateReceiver.class).setAction(ACTION);PendingIntent pending=PendingIntent.getBroadcast(context,ALARM_REQ,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);long at=SystemClock.elapsedRealtime()+Math.max(60000L,delay);alarm.cancel(pending);if(Build.VERSION.SDK_INT>=23)alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,at,pending);else alarm.set(AlarmManager.ELAPSED_REALTIME_WAKEUP,at,pending);}catch(SecurityException denied){try{AlarmManager alarm=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);Intent intent=new Intent(context,EpisodeUpdateReceiver.class).setAction(ACTION);PendingIntent pending=PendingIntent.getBroadcast(context,ALARM_REQ,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);if(alarm!=null)alarm.setWindow(AlarmManager.ELAPSED_REALTIME_WAKEUP,SystemClock.elapsedRealtime()+Math.max(60000L,delay),10L*60L*1000L,pending);}catch(Exception ignored){}}catch(Exception ignored){}}
    private static void schedulePeriodicJob(Context context){try{JobScheduler js=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(js==null)return;JobInfo.Builder b=new JobInfo.Builder(JOB_PERIODIC,new ComponentName(context,YoruUpdateJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).setPeriodic(PERIOD,5L*60L*1000L).setBackoffCriteria(5L*60L*1000L,JobInfo.BACKOFF_POLICY_EXPONENTIAL);js.schedule(b.build());}catch(Exception ignored){}}
    private static void scheduleOneShotJob(Context context,long delay){try{JobScheduler js=(JobScheduler)context.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(js==null)return;JobInfo.Builder b=new JobInfo.Builder(JOB_NOW,new ComponentName(context,YoruUpdateJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setMinimumLatency(Math.max(0L,delay)).setOverrideDeadline(Math.max(5000L,delay+20000L)).setBackoffCriteria(2L*60L*1000L,JobInfo.BACKOFF_POLICY_LINEAR);js.schedule(b.build());}catch(Exception ignored){}}

    @Override public void onReceive(Context context,Intent intent){Context c=context.getApplicationContext();schedule(c);YoruApp.app().discovery.execute(()->ScheduledDownloads.schedule(c));String action=intent==null?"":intent.getAction();if(Intent.ACTION_BOOT_COMPLETED.equals(action)||Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)||Intent.ACTION_TIME_CHANGED.equals(action)||Intent.ACTION_TIMEZONE_CHANGED.equals(action)){checkSoon(c);return;}BroadcastReceiver.PendingResult pending=goAsync();Runnable work=()->{try{performCheck(c,"alarm");}finally{try{pending.finish();}catch(Exception ignored){}}};YoruApp app=YoruApp.app();if(app!=null&&app.discovery!=null)app.discovery.execute(work);else new Thread(work,"yoru-update-alarm").start();}

    public static CheckResult performCheck(Context context,String reason){Context c=context.getApplicationContext();CheckResult result=new CheckResult();if(!RUNNING.compareAndSet(false,true)){result.shouldRetry=true;return result;}try{if(!hasNetwork(c)){result.shouldRetry=true;return result;}YoruApp app=YoruApp.app();SecureStore store=app!=null&&app.store!=null?app.store:new SecureStore(c);ApiRepository api=app!=null&&app.api!=null?app.api:new ApiRepository(c);YoruCache cache=app!=null?app.cache:null;try{if(cache==null)cache=new YoruCache(c);}catch(Exception ignored){}List<Anime> rows=store.favorites();if(rows.isEmpty()){store.updateCheckState(System.currentTimeMillis(),0,0,"Коллекция пуста");return result;}long started=System.currentTimeMillis(),deadline=started+MAX_BUDGET;int checked=0,alerts=0,errors=0;ArrayList<ApiRepository.AiringItem> airings=null;try{airings=api.airingSchedule(28,rows);ScheduledDownloads.refreshDates(c,airings);JSONArray json=ApiRepository.airingJson(airings);if(cache!=null)cache.schedule(json);store.calendarCache(json);if(app!=null)app.calendarTodayCount=ApiRepository.todayCount(airings);}catch(Exception ignored){}
        ArrayList<Anime> priority=new ArrayList<>(rows);priority.sort((a,b)->Boolean.compare(b.ongoing(),a.ongoing()));for(Anime base:priority){if(System.currentTimeMillis()>deadline||checked>=90)break;if(!Anime.valid(base))continue;checked++;try{Anime fresh=api.details(base,false);int released=Math.max(fresh.aired(),base.aired());if(released<=0&&"Закончен".equals(fresh.statusLabel()))released=fresh.totalEpisodes()>0?fresh.totalEpisodes():base.totalEpisodes();if(released<=0||base.metadataOnly())try{Anime.Playback ready=api.playback(base,"auto");if(ready!=null&&ready.video!=null&&!EpisodeRules.conflicts(fresh,ready.video))released=Math.max(released,countPlayable(ready.video));}catch(Exception ignored){}if(released<=0){fresh=api.details(base,true);released=Math.max(released,countPlayable(fresh));if(released<=0&&"Закончен".equals(fresh.statusLabel()))released=fresh.totalEpisodes()>0?fresh.totalEpisodes():base.totalEpisodes();}if(fresh.totalEpisodes()>0)released=Math.min(released,fresh.totalEpisodes());boolean changed=released>0&&store.updateFavoriteEpisodes(fresh,released);if(changed){alerts++;notify(c,fresh,released);if(store.autoDownloadNew()&&"watching".equals(store.bucket(fresh)))autoDownload(c,api,fresh,released);}}catch(Exception e){errors++;}}
        store.updateCheckState(System.currentTimeMillis(),checked,alerts,errors>0?"Ошибок: "+errors:"OK");try{YoruWidgetProvider.refresh(c);}catch(Exception ignored){}result.checked=checked;result.alerts=alerts;result.shouldRetry=errors>0&&checked<Math.min(5,rows.size());return result;}finally{RUNNING.set(false);}}

    private static void autoDownload(Context context,ApiRepository api,Anime anime,int released){
        try{
            YoruApp app=YoruApp.app();if(app==null)return;
            SecureStore store=app.store;if(store==null)return;
            if(app.traffic.metered()&&store.wifiDownloads())return;
            double seen=store.progress(anime).optDouble("episode",0);
            double target=Math.floor(seen)+1;
            if(target<1)target=1;
            if(target>released)return;
            Anime.Playback ready=api.playback(anime,"yoru");
            if(ready==null||ready.video==null)return;
            int limit=store.downloadResolution();
            List<ApiRepository.DownloadOption> options=api.downloadOptions(anime,ready,target,store.voicePreference(anime),limit,store.onlyPreferredVoice());
            if(options==null||options.isEmpty())return;
            ApiRepository.DownloadOption best=null;
            for(ApiRepository.DownloadOption option:options){
                if(option==null||option.episode==null||option.episode.future)continue;
                if(option.quality>0&&limit>0&&option.quality<=limit&&(best==null||option.quality>best.quality))best=option;
            }
            if(best==null)for(ApiRepository.DownloadOption option:options)if(option!=null&&option.episode!=null&&!option.episode.future){best=option;break;}
            if(best==null)return;
            app.downloads().enqueue(anime,best.source,best.episode,best.quality,best.voice,"");
        }catch(Exception ignored){}
    }
    private static boolean hasNetwork(Context c){try{ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);if(cm==null)return true;Network n=cm.getActiveNetwork();if(n==null)return false;NetworkCapabilities cap=cm.getNetworkCapabilities(n);return cap==null||cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);}catch(Exception e){return true;}}
    private static int countPlayable(Anime anime){return anime==null?0:EpisodeRules.available(EpisodeRules.visible(anime,anime.episodeList));}
    private static void notify(Context context,Anime anime,int episodes){if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(nm!=null)nm.createNotificationChannel(new NotificationChannel("yoru-updates",context.getString(R.string.updates_channel_name),NotificationManager.IMPORTANCE_HIGH));}Intent open=new Intent(context,DetailsActivity.class).putExtra("anime",anime.json().toString()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);int id=anime.key().hashCode()&0x7fffffff;PendingIntent pi=PendingIntent.getActivity(context,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder builder=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,"yoru-updates"):new Notification.Builder(context);Intent watch=new Intent(context,PlayerActivity.class).putExtra("anime",anime.json().toString()).putExtra("episode",(double)episodes).putExtra("mode","yoru").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent watchPi=PendingIntent.getActivity(context,900000+id,watch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Bitmap poster=poster(anime.poster);builder.setSmallIcon(R.drawable.ic_download).setContentTitle("Вышла новая серия").setContentText(anime.title+" · серия "+episodes).setContentIntent(pi).setAutoCancel(true).setShowWhen(true).setWhen(System.currentTimeMillis()).setCategory(Notification.CATEGORY_STATUS).addAction(R.drawable.ic_pip_play,"Смотреть",watchPi);if(Build.VERSION.SDK_INT>=21)builder.setColor(0xff9c5cff).setOnlyAlertOnce(true);if(Build.VERSION.SDK_INT<26)builder.setPriority(Notification.PRIORITY_HIGH);if(poster!=null)builder.setLargeIcon(poster).setStyle(new Notification.BigPictureStyle().bigPicture(poster).setSummaryText(anime.title+" · серия "+episodes));else builder.setStyle(new Notification.BigTextStyle().bigText(anime.title+" · появилась новая серия. Откройте карточку или сразу начните просмотр."));NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);if(nm!=null)nm.notify(2400+id%500000,builder.build());}
    private static Bitmap poster(String url){String safe=ApiRepository.safeUrl(url);if(safe.isEmpty())return null;HttpURLConnection c=null;try{c=HttpTransport.open(new URL(safe));c.setConnectTimeout(1800);c.setReadTimeout(2400);c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/149 Mobile Safari/537.36");try(InputStream in=c.getInputStream()){BitmapFactory.Options o=new BitmapFactory.Options();o.inSampleSize=2;return BitmapFactory.decodeStream(in,null,o);}}catch(Exception e){return null;}finally{if(c!=null)c.disconnect();}}
    public static final class CheckResult{public int checked,alerts;public boolean shouldRetry;}
}
