package app.yoru.mobile;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.util.AtomicFile;
import android.view.*;
import android.widget.*;
import java.io.*;

public final class WallpaperActivity extends Activity {
    private static final int PICK=4401;
    private final TaskQueue.Scope tasks=new TaskQueue.Scope();
    private CropView crop;
    private TextView save,state;
    private Switch enabled,transparent;
    private SeekBar opacity;
    private File draft;
    private String pendingPhoto="";
    private boolean ownsPhotoPermission;
    private boolean saving;
    private int generation;
    @Override public void onCreate(Bundle bundle){
        super.onCreate(bundle);if(!Ui.allow(this))return;LinearLayout root=Ui.base(this);LinearLayout heading=Ui.row(this);heading.addView(Ui.iconButton(this,"back","Отменить",this::finish),Ui.lp(this,48,48));heading.addView(Ui.text(this,"Обои и прозрачность",20,Ui.TEXT,true));root.addView(heading);
        ScrollView scroll=new ScrollView(this);LinearLayout body=Ui.column(this);body.setPadding(Ui.dp(this,16),0,Ui.dp(this,16),Ui.dp(this,24));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        body.addView(Ui.button(this,"Выбрать фото",false,this::pick),Ui.lp(this,-1,-2));state=Ui.text(this,"Перемещайте фото и меняйте масштаб двумя пальцами. Нажмите название вкладки, чтобы увидеть её с новыми обоями.",12,Ui.MUTED,false);Ui.space(body,10);body.addView(state);crop=new CropView();body.addView(crop,Ui.lp(this,-1,340));
        HorizontalScrollView tabs=new HorizontalScrollView(this);LinearLayout row=Ui.row(this);String[] names={"Главная","Каталог","Коллекция","Загрузки","Календарь"};for(int i=0;i<names.length;i++){int tab=i;row.addView(Ui.chip(this,names[i],false,()->{crop.tab=tab;preview();}),Ui.lp(this,-2,-2));}tabs.addView(row);body.addView(tabs);
        SecureStore store=YoruApp.app().store;enabled=new Switch(this);enabled.setText("Использовать обои");enabled.setTextColor(Ui.TEXT);enabled.setChecked(bundle==null?store.wallpaperEnabled():bundle.getBoolean("enabled"));body.addView(enabled);enabled.setOnCheckedChangeListener((button,value)->crop.invalidate());
        transparent=new Switch(this);transparent.setText("Прозрачные панели");transparent.setTextColor(Ui.TEXT);transparent.setChecked(bundle==null?store.wallpaperTransparent():bundle.getBoolean("transparent"));body.addView(transparent);transparent.setOnCheckedChangeListener((button,value)->crop.invalidate());
        TextView label=Ui.text(this,"Прозрачность панелей",12,Ui.MUTED,false);body.addView(label);opacity=new SeekBar(this);opacity.setMax(90);opacity.setProgress(bundle==null?store.wallpaperTransparency():bundle.getInt("opacity",45));body.addView(opacity);label.setText("Прозрачность панелей: "+opacity.getProgress()+"%");opacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar bar,int value,boolean user){label.setText("Прозрачность панелей: "+value+"%");crop.invalidate();}public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}});
        save=Ui.button(this,"Сохранить",true,this::save);Ui.space(body,12);body.addView(save,Ui.lp(this,-1,-2));body.addView(Ui.button(this,"Отменить",false,this::finish),Ui.lp(this,-1,-2));
        if(bundle!=null){crop.zoom=bundle.getFloat("zoom",1);crop.cx=bundle.getFloat("cx",.5f);crop.cy=bundle.getFloat("cy",.5f);crop.tab=bundle.getInt("tab",0);String name=bundle.getString("draft","");if(name.startsWith("wallpaper-draft-")&&!name.contains("/"))draft=new File(getFilesDir(),name);}
        File initial=draft!=null&&draft.isFile()?draft:new File(getFilesDir(),"wallpaper.png");if(initial.isFile())load(initial,false);
        if(bundle!=null){pendingPhoto=bundle.getString("pendingPhoto","");ownsPhotoPermission=bundle.getBoolean("ownsPhotoPermission",false);if(!pendingPhoto.isEmpty())importPhoto(Uri.parse(pendingPhoto));}
    }
    private void pick(){if(saving)return;Intent intent=Build.VERSION.SDK_INT>=33?new Intent(MediaStore.ACTION_PICK_IMAGES):new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE);intent.setType("image/*");try{startActivityForResult(intent,PICK);}catch(Exception e){Ui.toast(this,"Выбор фото недоступен");}}
    @Override protected void onActivityResult(int request,int code,Intent data){super.onActivityResult(request,code,data);if(request!=PICK||code!=RESULT_OK||data==null||data.getData()==null)return;releasePhotoPermission();Uri uri=data.getData();boolean retained=false;for(UriPermission permission:getContentResolver().getPersistedUriPermissions())if(permission.getUri().equals(uri)&&permission.isReadPermission()){retained=true;break;}if(!retained)try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);ownsPhotoPermission=true;}catch(SecurityException ignored){}importPhoto(uri);}
    private void releasePhotoPermission(){if(ownsPhotoPermission&&!pendingPhoto.isEmpty())try{getContentResolver().releasePersistableUriPermission(Uri.parse(pendingPhoto),Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}ownsPhotoPermission=false;pendingPhoto="";}
    private void importPhoto(Uri uri){pendingPhoto=uri.toString();int token=++generation;tasks.cancel();save.setEnabled(false);state.setText("Импортируем фото…");File target=new File(getFilesDir(),"wallpaper-draft-"+System.nanoTime());tasks.submit(YoruApp.app().io,()->{try{try(InputStream input=getContentResolver().openInputStream(uri);OutputStream output=new FileOutputStream(target)){if(input==null)throw new IOException();byte[] buffer=new byte[65536];long total=0;int count;while((count=input.read(buffer))!=-1){TaskQueue.check();total+=count;if(total>32L*1024*1024)throw new IOException();output.write(buffer,0,count);}}TaskQueue.check();runOnUiThread(()->{if(isDestroyed()||token!=generation){target.delete();return;}releasePhotoPermission();if(draft!=null)draft.delete();draft=target;load(target,true);});}catch(Exception e){target.delete();runOnUiThread(()->{if(!isDestroyed()&&token==generation){releasePhotoPermission();save.setEnabled(true);state.setText("Не удалось прочитать фото. Выберите изображение до 32 МБ.");if(crop.image==null){File previous=draft!=null&&draft.isFile()?draft:new File(getFilesDir(),"wallpaper.png");if(previous.isFile())load(previous,false);}}});}},()->{releasePhotoPermission();save.setEnabled(true);state.setText("Очередь занята");});}
    private static int orientation(File file){try{return new ExifInterface(file.getPath()).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);}catch(IOException e){return ExifInterface.ORIENTATION_NORMAL;}}
    private void load(File file,boolean newlyPicked){int token=++generation;save.setEnabled(false);tasks.submit(YoruApp.app().io,()->{Bitmap image=null;try{BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeFile(file.getPath(),options);if(options.outWidth<=0||options.outHeight<=0)throw new IOException();options.inJustDecodeBounds=false;options.inSampleSize=1;while((long)(options.outWidth/options.inSampleSize)*(options.outHeight/options.inSampleSize)>3145728)options.inSampleSize*=2;image=BitmapFactory.decodeFile(file.getPath(),options);if(image==null)throw new IOException();int orientation=orientation(file);Matrix matrix=new Matrix();switch(orientation){case 2:matrix.setScale(-1,1);break;case 3:matrix.setRotate(180);break;case 4:matrix.setScale(1,-1);break;case 5:matrix.setRotate(90);matrix.postScale(-1,1);break;case 6:matrix.setRotate(90);break;case 7:matrix.setRotate(270);matrix.postScale(-1,1);break;case 8:matrix.setRotate(270);break;}if(!matrix.isIdentity()){Bitmap rotated=Bitmap.createBitmap(image,0,0,image.getWidth(),image.getHeight(),matrix,true);if(rotated!=image)image.recycle();image=rotated;}Bitmap ready=image;runOnUiThread(()->{if(isDestroyed()||token!=generation){ready.recycle();return;}Bitmap previous=crop.image;crop.image=ready;if(previous!=null&&previous!=ready&&!previous.isRecycled())previous.recycle();if(newlyPicked){crop.zoom=1;crop.cx=.5f;crop.cy=.5f;enabled.setChecked(true);}save.setEnabled(true);state.setText("Настройте кадр и прозрачность. Предпросмотр открывает настоящие вкладки, не изменяя сохранённые обои.");crop.invalidate();});}catch(Exception|OutOfMemoryError e){if(image!=null)image.recycle();runOnUiThread(()->{if(!isDestroyed()&&token==generation){save.setEnabled(true);state.setText("Это изображение не удалось открыть");}});}},()->{save.setEnabled(true);state.setText("Очередь занята");});}
    private void preview(){
        if(saving||save==null||!save.isEnabled())return;
        if(enabled.isChecked()&&crop.image==null){Ui.toast(this,"Сначала выберите фото");return;}
        boolean active=enabled.isChecked(),glass=transparent.isChecked();int alpha=opacity.getProgress(),tab=crop.tab;
        if(!active){startActivity(new Intent(this,WallpaperPreviewActivity.class).putExtra("previewTab",tab));return;}
        saving=true;save.setEnabled(false);state.setText("Готовим предпросмотр…");Bitmap image=crop.image;int[] selection=CropGeometry.window(image.getWidth(),image.getHeight(),crop.aspect,crop.zoom,crop.cx,crop.cy);File target=new File(getFilesDir(),"wallpaper-preview-"+System.nanoTime()+".png");
        tasks.submit(YoruApp.app().io,()->{Bitmap result=null;try{int width=Math.min(1080,selection[2]),height=Math.max(1,Math.round(width*crop.aspect));result=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);new Canvas(result).drawBitmap(image,new Rect(selection[0],selection[1],selection[0]+selection[2],selection[1]+selection[3]),new Rect(0,0,width,height),new Paint(Paint.FILTER_BITMAP_FLAG));try(OutputStream output=new FileOutputStream(target)){if(!result.compress(Bitmap.CompressFormat.PNG,100,output))throw new IOException();}TaskQueue.check();runOnUiThread(()->{if(isDestroyed()){target.delete();return;}saving=false;save.setEnabled(true);state.setText("Обои ещё не сохранены. Можно продолжить настройку.");startActivity(new Intent(this,WallpaperPreviewActivity.class).putExtra("previewFile",target.getName()).putExtra("previewEnabled",true).putExtra("previewTransparent",glass).putExtra("previewOpacity",alpha).putExtra("previewTab",tab));});}catch(Exception|OutOfMemoryError error){target.delete();runOnUiThread(()->{if(!isDestroyed()){saving=false;save.setEnabled(true);state.setText("Не удалось открыть предпросмотр");}});}finally{if(result!=null)result.recycle();}},()->{saving=false;save.setEnabled(true);state.setText("Не удалось подготовить предпросмотр");});
    }
    private void save(){if(saving)return;if(enabled.isChecked()&&crop.image==null){Ui.toast(this,"Сначала выберите фото");return;}boolean active=enabled.isChecked(),glass=transparent.isChecked();int alpha=opacity.getProgress();if(!active){YoruApp.app().store.wallpaper(false,glass,alpha);finish();return;}saving=true;save.setEnabled(false);state.setText("Сохраняем обои…");Bitmap image=crop.image;int[] selection=CropGeometry.window(image.getWidth(),image.getHeight(),crop.aspect,crop.zoom,crop.cx,crop.cy);tasks.submit(YoruApp.app().io,()->{AtomicFile target=new AtomicFile(new File(getFilesDir(),"wallpaper.png"));FileOutputStream output=null;Bitmap result=null;try{int width=Math.min(1080,selection[2]),height=Math.max(1,Math.round(width*crop.aspect));result=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);new Canvas(result).drawBitmap(image,new Rect(selection[0],selection[1],selection[0]+selection[2],selection[1]+selection[3]),new Rect(0,0,width,height),new Paint(Paint.FILTER_BITMAP_FLAG));output=target.startWrite();if(!result.compress(Bitmap.CompressFormat.PNG,100,output))throw new IOException();TaskQueue.check();target.finishWrite(output);output=null;YoruApp.app().store.wallpaper(true,glass,alpha);runOnUiThread(()->{if(!isDestroyed()){Ui.toast(this,"Обои сохранены");finish();}});}catch(Exception|OutOfMemoryError e){if(output!=null)target.failWrite(output);runOnUiThread(()->{if(!isDestroyed()){saving=false;save.setEnabled(true);state.setText("Не удалось сохранить. Прежние настройки не изменены.");}});}finally{if(result!=null)result.recycle();}},()->{saving=false;save.setEnabled(true);state.setText("Очередь занята");});}
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);if(crop==null)return;out.putString("pendingPhoto",pendingPhoto);out.putBoolean("ownsPhotoPermission",ownsPhotoPermission);out.putBoolean("enabled",enabled.isChecked());out.putBoolean("transparent",transparent.isChecked());out.putInt("opacity",opacity.getProgress());out.putFloat("zoom",crop.zoom);out.putFloat("cx",crop.cx);out.putFloat("cy",crop.cy);out.putInt("tab",crop.tab);if(draft!=null)out.putString("draft",draft.getName());}
    @Override protected void onDestroy(){generation++;tasks.cancel();if(!isChangingConfigurations()){releasePhotoPermission();if(draft!=null)draft.delete();}super.onDestroy();}
    private final class CropView extends View {
        Bitmap image;float zoom=1,cx=.5f,cy=.5f,x,y;int tab,pointer=-1;final float aspect=getResources().getDisplayMetrics().heightPixels/(float)getResources().getDisplayMetrics().widthPixels;final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);final RectF frame=new RectF();final ScaleGestureDetector scale;
        CropView(){
            super(WallpaperActivity.this);setContentDescription("Кадр обоев. Перемещайте фото одним пальцем, масштабируйте двумя.");
            scale=new ScaleGestureDetector(WallpaperActivity.this,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
                @Override public boolean onScale(ScaleGestureDetector detector){
                    float factor=detector.getScaleFactor();if(saving||!Float.isFinite(factor)||factor<=0)return false;
                    float next=Math.max(1,Math.min(8,zoom*factor));
                    if(image!=null&&frame.width()>0&&frame.height()>0){
                        float fx=Math.max(0,Math.min(1,(detector.getFocusX()-frame.left)/frame.width())),fy=Math.max(0,Math.min(1,(detector.getFocusY()-frame.top)/frame.height()));
                        int[] old=CropGeometry.window(image.getWidth(),image.getHeight(),aspect,zoom,cx,cy),region=CropGeometry.window(image.getWidth(),image.getHeight(),aspect,next,cx,cy);
                        cx=Math.max(0,Math.min(1,(old[0]+fx*old[2]+(.5f-fx)*region[2])/image.getWidth()));
                        cy=Math.max(0,Math.min(1,(old[1]+fy*old[3]+(.5f-fy)*region[3])/image.getHeight()));
                    }
                    zoom=next;invalidate();return true;
                }
            });
        }
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float h=getHeight()-Ui.dp(getContext(),16),w=Math.min(getWidth(),h/aspect);h=w*aspect;frame.set((getWidth()-w)/2,(getHeight()-h)/2,(getWidth()+w)/2,(getHeight()+h)/2);paint.setColor(Ui.BG);paint.setAlpha(255);canvas.drawRect(frame,paint);if(image!=null&&enabled!=null&&enabled.isChecked()){int[] source=CropGeometry.window(image.getWidth(),image.getHeight(),aspect,zoom,cx,cy);canvas.drawBitmap(image,new Rect(source[0],source[1],source[0]+source[2],source[1]+source[3]),frame,paint);paint.setColor(Ui.BG);paint.setAlpha(105);canvas.drawRect(frame,paint);}paint.setAlpha(255);paint.setColor(Ui.PURPLE);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1);canvas.drawRect(frame,paint);paint.setStyle(Paint.Style.FILL);}
        @Override public boolean onTouchEvent(MotionEvent event){
            if(saving)return true;scale.onTouchEvent(event);int action=event.getActionMasked();
            if(action==MotionEvent.ACTION_DOWN){pointer=event.getPointerId(0);x=event.getX();y=event.getY();getParent().requestDisallowInterceptTouchEvent(true);}
            else if(action==MotionEvent.ACTION_POINTER_UP){int index=event.getActionIndex();if(event.getPointerId(index)==pointer){int next=index==0?1:0;pointer=event.getPointerId(next);x=event.getX(next);y=event.getY(next);}}
            else if(action==MotionEvent.ACTION_MOVE){
                int index=event.findPointerIndex(pointer);if(index<0)return true;float nextX=event.getX(index),nextY=event.getY(index);
                if(!scale.isInProgress()&&event.getPointerCount()==1&&image!=null&&frame.width()>0&&frame.height()>0){int[] region=CropGeometry.window(image.getWidth(),image.getHeight(),aspect,zoom,cx,cy);cx=Math.max(0,Math.min(1,cx-(nextX-x)/frame.width()*region[2]/image.getWidth()));cy=Math.max(0,Math.min(1,cy-(nextY-y)/frame.height()*region[3]/image.getHeight()));invalidate();}
                x=nextX;y=nextY;
            }else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){pointer=-1;getParent().requestDisallowInterceptTouchEvent(false);}
            return true;
        }
    }
}
