package app.yoru.mobile;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;

public final class DetailsActivity extends Activity {
    private RecyclerView episodeRecycler;private EpisodeAdapter episodeAdapter;private volatile Future<Anime.Playback> earlyPlayback;
    private final ArrayList<Anime.Episode> displayedEpisodes=new ArrayList<>();private long wallpaperVersion;private InlinePlayer inlinePlayer;private Anime anime;private LinearLayout root,body,headerSection,episodeSection,moreSection;private androidx.core.widget.NestedScrollView detailScroll;private TextView state;private int generation,downloadsGeneration;private boolean loaded,episodesLoaded,favoriteCached;private String bucketCached="",relatedFilter="";private JSONObject progressCached=new JSONObject();private HashMap<String,androidx.media3.exoplayer.offline.Download> completed=new HashMap<>();private Future<?> detailFuture,downloadFuture;
    private final TaskQueue.Scope watchTasks=new TaskQueue.Scope();
    private int watchGeneration;private Ui.Progress watchProgress;
    private static final class WatchPack {Anime.Playback playback;Anime.Episode episode;String[] names,values;int selected;}
    @Override public void onCreate(Bundle b){super.onCreate(b);if(!Ui.allow(this))return;anime=Ui.intentAnime(this);if(b!=null&&b.containsKey("selectedAnime"))try{Anime restored=Anime.from(new JSONObject(b.getString("selectedAnime")));if(Anime.valid(restored))anime=restored;}catch(Exception ignored){}if(!Anime.valid(anime)){finish();return;}YoruApp.app().api.remember(anime);root=Ui.base(this);wallpaperVersion=YoruApp.app().store.wallpaperVersion();LinearLayout bar=Ui.row(this);bar.setPadding(Ui.dp(this,16),Ui.dp(this,9),Ui.dp(this,16),Ui.dp(this,9));bar.addView(Ui.iconButton(this,"back","Назад",this::finish),Ui.lp(this,44,44));TextView label=Ui.text(this,"YORU",13,Ui.MUTED,true);Ui.gap(bar,label,-2,-2,13);root.addView(bar,Ui.lp(this,-1,-2));androidx.core.widget.NestedScrollView scroll=new androidx.core.widget.NestedScrollView(this);detailScroll=scroll;scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);body=Ui.column(this);inlinePlayer=new InlinePlayer(this);inlinePlayer.setSeasonListener(this::selectSeason);headerSection=Ui.column(this);episodeSection=Ui.column(this);moreSection=Ui.column(this);body.addView(headerSection,Ui.lp(this,-1,-2));body.addView(inlinePlayer,Ui.lp(this,-1,-2));body.addView(episodeSection,Ui.lp(this,-1,-2));body.addView(moreSection,Ui.lp(this,-1,-2));body.setPadding(Ui.dp(this,20),Ui.dp(this,12),Ui.dp(this,20),Ui.dp(this,30));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));render();if(b!=null)inlinePlayer.restoreState(b.getBundle("inlineState"));loadDownloads();loadFull();}
    @Override protected void onResume(){super.onResume();if(root!=null&&wallpaperVersion!=YoruApp.app().store.wallpaperVersion()){wallpaperVersion=YoruApp.app().store.wallpaperVersion();WallpaperStyle.apply(this,root);}if(body!=null){render();inlinePlayer.resumeLifecycle();loadDownloads();}}
    private void selectSeason(Anime value){
        if(dead()||!Anime.valid(value))return;
        cancelWatchPreparation();anime=snapshot(value);loaded=false;episodesLoaded=false;completed.clear();displayedEpisodes.clear();
        loadFull();loadDownloads();detailScroll.smoothScrollTo(0,headerSection.getTop());
    }
    private Anime snapshot(Anime value){Anime copy=Anime.from(value.json());copy.episodeList.addAll(value.episodeList);copy.related.addAll(value.related);copy.blocked=value.blocked;return copy;}
    private boolean currentLoad(int token){return token==generation&&!dead();}
    private final java.util.concurrent.ExecutorService cardPool=TaskQueue.pool(3);
    private void updateMetadata(Anime value,int token){
        if(!currentLoad(token)||EpisodeRules.conflicts(anime,value))return;
        Anime next=snapshot(value);ArrayList<Anime.Episode> merged=new ArrayList<>(next.episodeList);merged.addAll(anime.episodeList);next.episodeList.clear();next.episodeList.addAll(EpisodeRules.visible(next,merged));
        anime=next;loaded=true;render();loadDownloads();prefetchRelated();
    }
    private void loadFull(){
        int token=++generation;if(detailFuture!=null)detailFuture.cancel(true);if(earlyPlayback!=null)earlyPlayback.cancel(true);
        Anime seed=snapshot(anime);episodesLoaded=false;render();
        earlyPlayback=cardPool.submit(()->{
            try{Anime.Playback result=YoruApp.app().api.playback(seed,"yoru");TaskQueue.check();
                YoruApp.app().main.post(()->{
                    if(!currentLoad(token))return;episodesLoaded=true;
                    if(result!=null&&result.video!=null&&!EpisodeRules.conflicts(anime,result.video)&&!result.video.episodeList.isEmpty()){
                        Anime next=snapshot(anime);next.episodeList.clear();next.episodeList.addAll(EpisodeRules.visible(anime,result.video.episodeList));
                        if(next.episodes<=0)next.episodes=result.video.episodes;
                        next.episodesAired=Math.max(next.episodesAired,result.video.episodesAired>0?result.video.episodesAired:playableCount(next.episodeList));
                        anime=next;inlinePlayer.offerEpisodes(anime,result);
                    }render();loadDownloads();
                });return result;
            }catch(Exception error){YoruApp.app().main.post(()->{if(currentLoad(token)){episodesLoaded=true;render();}});return null;}
        });
        detailFuture=cardPool.submit(()->{
            Anime meta=seed;
            try{meta=YoruApp.app().api.quickDetails(seed);TaskQueue.check();Anime quick=snapshot(meta);YoruApp.app().main.post(()->updateMetadata(quick,token));}catch(Exception ignored){}
            if(Thread.currentThread().isInterrupted())return;
            try{Anime full=snapshot(YoruApp.app().api.details(meta,true));TaskQueue.check();YoruApp.app().main.post(()->updateMetadata(full,token));}
            catch(Exception error){YoruApp.app().main.post(()->{if(currentLoad(token)){loaded=true;render();}});}
        });
        if(earlyPlayback.isCancelled()){episodesLoaded=true;render();}
    }
    private void loadDownloads(){final int gen=++downloadsGeneration;if(downloadFuture!=null)downloadFuture.cancel(true);final Anime snapshot=Anime.from(anime.json());downloadFuture=YoruApp.app().ui.submit(()->{HashMap<String,androidx.media3.exoplayer.offline.Download> rows=YoruApp.app().downloads().completedEpisodes(snapshot);YoruApp.app().main.post(()->{if(gen==downloadsGeneration&&!isFinishing()){if(!completed.keySet().equals(rows.keySet())){completed=rows;if(episodeAdapter!=null)episodeAdapter.updateRows();}else completed=rows;}});});}
    private void render(){progressCached=YoruApp.app().store.progress(anime);bucketCached=YoruApp.app().store.bucket(anime);favoriteCached=YoruApp.app().store.favorite(anime);prepareEpisodeDisplay();headerSection.removeAllViews();moreSection.removeAllViews();LinearLayout body=headerSection;LinearLayout hero=Ui.row(this);hero.setGravity(Gravity.TOP);ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setBackground(Ui.gradient(0xff2a2135,0xff18131f,16,this));image.setClipToOutline(true);hero.addView(image,Ui.lp(this,126,184));YoruApp.app().images.load(image,anime);LinearLayout info=Ui.column(this);info.setPadding(Ui.dp(this,17),Ui.dp(this,3),0,0);TextView source=Ui.label(this,topLabel());source.setTextColor(Ui.PURPLE);info.addView(source);Ui.space(info,11);TextView title=Ui.text(this,YoruBrain.title(anime),23,Ui.TEXT,true);title.setMaxLines(6);info.addView(title);Ui.space(info,12);info.addView(Ui.text(this,anime.cardMeta()+(anime.studio.isEmpty()?"":" · "+anime.studio),11,Ui.MUTED,false));if(anime.ratingScore()>0){Ui.space(info,9);info.addView(Ui.text(this,String.format(Locale.US,"★ %.1f",anime.ratingScore()),15,Ui.PURPLE,true));}hero.addView(info,new LinearLayout.LayoutParams(0,-2,1));body.addView(hero);Ui.space(body,18);chips(body);about(body);Ui.space(body,12);body.addView(Ui.button(this,"Список серий",false,()->detailScroll.smoothScrollTo(0,episodeSection.getTop())),Ui.lp(this,-1,48));Ui.space(body,12);inlinePlayer.bind(anime);episodes();actions(moreSection);progress(moreSection);richCard(moreSection);screenshots(moreSection);trailerBlock(moreSection);related(moreSection);similar(moreSection);WallpaperStyle.refreshSurfaces(root);}
    private void chips(LinearLayout body){if(!anime.original.isEmpty()&&!anime.original.equals(anime.title)){body.addView(Ui.text(this,anime.original,12,Ui.MUTED,false));Ui.space(body,13);}if(!anime.genres.isEmpty()){HorizontalScrollView h=new HorizontalScrollView(this);h.setHorizontalScrollBarEnabled(false);LinearLayout row=Ui.row(this);for(String g:anime.genres){TextView chip=Ui.chip(this,g,false,()->startActivity(new android.content.Intent(this,MainActivity.class).putExtra("genreName",g).putExtra("genreSource","shikimori").putExtra("genreId",anime.shikimoriGenreIds.get(g))));LinearLayout.LayoutParams p=Ui.lp(this,-2,-2);p.rightMargin=Ui.dp(this,7);row.addView(chip,p);}h.addView(row);body.addView(h,Ui.lp(this,-1,-2));Ui.space(body,14);}String status=anime.statusLabel();String eps=anime.episodesLine();String next=anime.ongoing()&&!anime.nextEpisodeAt.isEmpty()?" · следующая: "+airText(anime.nextEpisodeAt):"";body.addView(Ui.text(this,status+(eps.isEmpty()?"":" · "+eps)+next+(anime.age.isEmpty()?"":" · "+anime.age),11,Ui.MUTED,false));Ui.space(body,18);}
    private void actions(LinearLayout body){JSONObject history=progressCached;String play=history.length()>0?"Продолжить":"Смотреть";String storedMode=history.optString("playerMode","");if(storedMode.trim().isEmpty()||storedMode.equals("auto"))storedMode="yoru";final String playMode=storedMode;double startEpisode=history.optDouble("episode",1);boolean available=EpisodeRules.allowsNumber(anime,startEpisode);androidx.media3.exoplayer.offline.Download offline=completed.get(DownloadHub.episodeKey(startEpisode));TextView start=Ui.button(this,anime.blocked?"Просмотр ограничен":!available?"Выбрать доступную серию":(offline!=null?"Смотреть скачанное":""+play+" · "+defaultVoiceName()+" · "+qualityName(YoruApp.app().store.quality())),true,()->{if(!available)detailScroll.smoothScrollTo(0,episodeSection.getTop());else if(offline!=null)Ui.openOffline(this,offline.request.id,anime,startEpisode);else openWatch(startEpisode,playMode);});start.setEnabled(!anime.blocked);if(anime.blocked)start.setAlpha(.45f);body.addView(start,Ui.lp(this,-1,-2));Ui.space(body,10);voiceInfoCard(body);Ui.space(body,10);LinearLayout main=Ui.row(this);main.addView(Ui.button(this,favoriteCached?"В коллекции":"В коллекцию",false,()->Ui.bucketDialog(this,anime,this::render)),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(0,-2,1);dp.leftMargin=Ui.dp(this,9);main.addView(Ui.button(this,"Скачать · "+downloadVoiceName(),false,()->DownloadActions.chooseEpisodeFast(this,anime,null,history.optDouble("episode",1),anime.episodeList)),dp);body.addView(main);
        Ui.space(body,9);body.addView(Ui.button(this,"Поделиться",false,this::shareAnime),Ui.lp(this,-1,-2));}

    private void shareAnime(){
        String link="";
        if("shikimori".equals(anime.source)&&anime.id!=null&&!anime.id.isEmpty())link="https://shikimori.one/animes/"+anime.id;
        else if(anime.malId>0)link="https://myanimelist.net/anime/"+anime.malId;
        String text=YoruBrain.title(anime)+(link.isEmpty()?"":" — "+link);
        try{startActivity(android.content.Intent.createChooser(new android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain").putExtra(android.content.Intent.EXTRA_TEXT,text),"Поделиться"));}
        catch(Exception error){Ui.toast(this,"Не удалось открыть меню отправки");}
    }
    private void progress(LinearLayout body){JSONObject history=progressCached;if(history.length()>0){Ui.space(body,10);body.addView(Ui.text(this,EpisodeRules.allowsNumber(anime,history.optDouble("episode",1))?"Вы смотрели серию "+Ui.number(history.optDouble("episode",1))+" · "+Ui.time(history.optInt("time")):"Сохранённая серия отсутствует в актуальном составе. Выберите доступную серию.",11,Ui.MUTED,false));}String bucket=bucketCached;if(!bucket.isEmpty()){int i=Arrays.asList(SecureStore.BUCKETS).indexOf(bucket);Ui.space(body,7);body.addView(Ui.text(this,"Ваш список: "+(i>=0?SecureStore.BUCKET_LABELS[i]:"В планах")+(YoruApp.app().store.folderSummary(anime).isEmpty()?"":" · папки: "+YoruApp.app().store.folderSummary(anime)),11,Ui.PURPLE,false));}String hint=anime.episodeList.isEmpty()?(episodesLoaded?"Список серий пока недоступен. Попробуйте открыть просмотр.":"Карточка открыта. Серии появятся автоматически."):"Просмотр: "+defaultVoiceName()+" · "+qualityName(YoruApp.app().store.quality())+".";state=Ui.text(this,hint,11,Ui.MUTED,false);if(!state.getText().toString().isEmpty()){Ui.space(body,12);body.addView(state);}}
    private void episodes(){LinearLayout body=episodeSection;body.removeAllViews();Ui.space(body,16);LinearLayout row=Ui.row(this);row.addView(Ui.text(this,"Серии",21,Ui.TEXT,true),new LinearLayout.LayoutParams(0,-2,1));if(!displayedEpisodes.isEmpty()){TextView pack=Ui.text(this,"Скачать дальше",10,Ui.PURPLE,true);pack.setPadding(Ui.dp(this,9),Ui.dp(this,7),Ui.dp(this,9),Ui.dp(this,7));pack.setBackground(Ui.stroke(Ui.SURFACE,10,this));Ui.press(pack);pack.setOnClickListener(v->DownloadActions.chooseBatchFast(this,anime,null,progressCached.optDouble("episode",1),displayedEpisodes));row.addView(pack);}else if(anime.totalEpisodes()>0)row.addView(Ui.text(this,String.valueOf(anime.totalEpisodes()),13,Ui.PURPLE,true));View refresh=Ui.iconButton(this,"refresh","Обновить список серий",this::loadFull);refresh.setEnabled(episodesLoaded);row.addView(refresh,Ui.lp(this,48,48));body.addView(row);Ui.space(body,12);
        if(displayedEpisodes.size()>24){LinearLayout jump=Ui.row(this);jump.setGravity(Gravity.CENTER_VERTICAL);
            EditText field=new EditText(this);field.setHint("Номер серии");field.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            field.setTextColor(Ui.TEXT);field.setHintTextColor(Ui.MUTED);field.setTextSize(13);field.setSingleLine();
            field.setPadding(Ui.dp(this,12),Ui.dp(this,8),Ui.dp(this,12),Ui.dp(this,8));field.setBackground(Ui.stroke(Ui.CARD,12,this));
            TextView go=Ui.text(this,"Перейти",11,Ui.PURPLE,true);go.setPadding(Ui.dp(this,14),Ui.dp(this,9),Ui.dp(this,14),Ui.dp(this,9));
            go.setBackground(Ui.stroke(Ui.SURFACE,12,this));Ui.press(go);
            go.setOnClickListener(v->{String raw=field.getText()==null?"":field.getText().toString().trim();if(raw.isEmpty())return;int target;
                try{target=Integer.parseInt(raw);}catch(Exception error){Ui.toast(this,"Введите номер серии");return;}
                for(int i=0;i<displayedEpisodes.size();i++)if(Math.abs(displayedEpisodes.get(i).number-target)<0.001){
                    if(episodeRecycler!=null)episodeRecycler.smoothScrollToPosition(i);return;}
                Ui.toast(this,"Серии с таким номером нет в списке");});
            jump.addView(field,new LinearLayout.LayoutParams(0,Ui.dp(this,44),1));
            LinearLayout.LayoutParams gp=Ui.lp(this,-2,-2);gp.leftMargin=Ui.dp(this,8);jump.addView(go,gp);body.addView(jump);Ui.space(body,10);}
        if(displayedEpisodes.isEmpty()){LinearLayout card=card();card.addView(Ui.text(this,episodesLoaded?"Список серий сейчас недоступен. Можно повторить загрузку.":"Загружаем список серий…",12,Ui.MUTED,false));Ui.space(card,10);TextView retry=Ui.button(this,"Загрузить список серий",false,this::loadFull);retry.setEnabled(episodesLoaded);card.addView(retry,Ui.lp(this,-1,48));body.addView(card);return;}if(episodeRecycler==null){episodeRecycler=new RecyclerView(this);episodeRecycler.setLayoutManager(new LinearLayoutManager(this));episodeRecycler.setHasFixedSize(false);episodeRecycler.setItemViewCacheSize(10);episodeRecycler.setNestedScrollingEnabled(true);episodeRecycler.setClipToPadding(false);episodeRecycler.setPadding(0,0,0,Ui.dp(this,6));episodeAdapter=new EpisodeAdapter();episodeRecycler.setAdapter(episodeAdapter);}RecyclerView rv=episodeRecycler;ViewParent oldParent=rv.getParent();if(oldParent instanceof ViewGroup)((ViewGroup)oldParent).removeView(rv);episodeAdapter.updateRows();int visible=Math.max(3,Math.min(8,displayedEpisodes.size()));body.addView(rv,Ui.lp(this,-1,visible*78));if(displayedEpisodes.size()>visible){Ui.space(body,7);body.addView(Ui.text(this,"Прокрутите список серий внутри блока.",10,Ui.MUTED,false));}}
    private boolean futureEpisode(Anime.Episode ep) {
        return ep.future;
    }

    private String episodeDate(Anime.Episode ep) {
        if (!ep.airDate.isEmpty()) return ep.airDate;
        return Math.round(ep.number) == anime.episodesAired + 1 && !anime.nextEpisodeAt.isEmpty()
                ? "Выйдет " + airText(anime.nextEpisodeAt) : "Дата уточняется";
    }

    private void planEpisode(Anime.Episode ep) {
        long due=0;
        if(Math.abs(ep.number-anime.episodesAired-1)<0.001) {
            try { due=java.time.OffsetDateTime.parse(anime.nextEpisodeAt).toInstant().toEpochMilli(); }
            catch(Exception ignored) {}
        }
        ScheduledDownloads.choose(this,anime,ep.number,due,episodeDate(ep));
    }

    private final class EpisodeAdapter extends RecyclerView.Adapter<EpisodeHolder> {
        private ArrayList<Anime.Episode> rows=new ArrayList<>();
        private ArrayList<String> signatures=new ArrayList<>();
        void updateRows() {
            ArrayList<Anime.Episode> next=new ArrayList<>();
            ArrayList<String> sig=new ArrayList<>();
            for(Anime.Episode ep:displayedEpisodes) {
                if(ep==null)continue;
                next.add(ep);
                androidx.media3.exoplayer.offline.Download done=completed.get(DownloadHub.episodeKey(ep.number));
                sig.add(ep.number+"|"+ep.name+"|"+futureEpisode(ep)+"|"+episodeDate(ep)+"|"+episodePoster(ep)+"|"+ep.duration+"|"+progressCached.optDouble("episode",-1)+"|"+(done==null?"":done.request.id)+"|"+downloadVoiceName()+"|"+YoruApp.app().store.spoilerSafe());
            }
            ArrayList<Anime.Episode> old=rows;
            ArrayList<String> oldSig=signatures;
            DiffUtil.DiffResult diff=DiffUtil.calculateDiff(new DiffUtil.Callback() {
                public int getOldListSize(){return old.size();}
                public int getNewListSize(){return next.size();}
                public boolean areItemsTheSame(int a,int b){return Double.compare(old.get(a).number,next.get(b).number)==0;}
                public boolean areContentsTheSame(int a,int b){return oldSig.get(a).equals(sig.get(b));}
                public Object getChangePayload(int a,int b){return Boolean.TRUE;}
            });
            rows=next;signatures=sig;diff.dispatchUpdatesTo(this);
        }
        public int getItemCount(){return rows.size();}
        public EpisodeHolder onCreateViewHolder(ViewGroup parent,int type){return new EpisodeHolder();}
        public void onBindViewHolder(EpisodeHolder holder,int position){holder.bind(rows.get(position));}
        public void onBindViewHolder(EpisodeHolder holder,int position,List<Object> payloads){holder.bind(rows.get(position));}
        public void onViewRecycled(EpisodeHolder holder){holder.episode=null;holder.imageKey="";holder.shot.setTag(null);holder.shot.setImageDrawable(null);}
    }

    private final class EpisodeHolder extends RecyclerView.ViewHolder {
        final LinearLayout outer,card;
        final ImageView shot;
        final TextView placeholder,play,title,subtitle,download;
        Anime.Episode episode;
        String imageKey="";
        EpisodeHolder() {
            super(Ui.column(DetailsActivity.this));
            outer=(LinearLayout)itemView;
            outer.setLayoutParams(new RecyclerView.LayoutParams(-1,-2));
            outer.setPadding(0,0,0,Ui.dp(DetailsActivity.this,8));
            card=Ui.row(DetailsActivity.this);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(Ui.dp(DetailsActivity.this,10),Ui.dp(DetailsActivity.this,9),Ui.dp(DetailsActivity.this,10),Ui.dp(DetailsActivity.this,9));
            card.setBackground(Ui.stroke(Ui.CARD,14,DetailsActivity.this));
            FrameLayout preview=new FrameLayout(DetailsActivity.this);
            preview.setBackground(Ui.shape(Ui.SURFACE,12,DetailsActivity.this));preview.setClipToOutline(true);
            shot=new ImageView(DetailsActivity.this);shot.setScaleType(ImageView.ScaleType.CENTER_CROP);
            preview.addView(shot,new FrameLayout.LayoutParams(-1,-1));
            placeholder=Ui.text(DetailsActivity.this,"",11,Ui.PURPLE,true);placeholder.setGravity(Gravity.CENTER);placeholder.setMaxLines(3);
            preview.addView(placeholder,new FrameLayout.LayoutParams(-1,-1));
            play=Ui.text(DetailsActivity.this,"▶",17,Ui.TEXT,true);play.setGravity(Gravity.CENTER);play.setBackground(Ui.shape(0x66000000,24,DetailsActivity.this));
            preview.addView(play,new FrameLayout.LayoutParams(Ui.dp(DetailsActivity.this,34),Ui.dp(DetailsActivity.this,34),Gravity.CENTER));
            LinearLayout.LayoutParams pp=Ui.lp(DetailsActivity.this,94,56);pp.rightMargin=Ui.dp(DetailsActivity.this,11);card.addView(preview,pp);
            LinearLayout text=Ui.column(DetailsActivity.this);
            title=Ui.text(DetailsActivity.this,"",12,Ui.TEXT,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);text.addView(title);
            Ui.space(text,4);subtitle=Ui.text(DetailsActivity.this,"",10,Ui.MUTED,false);text.addView(subtitle);
            card.addView(text,new LinearLayout.LayoutParams(0,-2,1));
            download=Ui.text(DetailsActivity.this,"",10,Ui.PURPLE,true);download.setGravity(Gravity.CENTER);download.setMaxLines(3);
            download.setPadding(Ui.dp(DetailsActivity.this,8),Ui.dp(DetailsActivity.this,7),Ui.dp(DetailsActivity.this,8),Ui.dp(DetailsActivity.this,7));
            download.setBackground(Ui.stroke(Ui.SURFACE,10,DetailsActivity.this));card.addView(download);outer.addView(card);
            Ui.press(card);Ui.press(download);
            download.setOnClickListener(v->open(true));card.setOnClickListener(v->open(false));
            card.setOnLongClickListener(v->{
                Anime.Episode ep=episode;if(ep==null||futureEpisode(ep))return true;
                YoruApp.app().store.progress(anime,ep.number,0,0,"yoru","",true);YoruWidgetProvider.refresh(DetailsActivity.this);
                progressCached=YoruApp.app().store.progress(anime);episodeAdapter.updateRows();
                Ui.toast(DetailsActivity.this,"Отмечено: серия "+Ui.number(ep.number));return true;
            });
        }
        void open(boolean downloadAction) {
            Anime.Episode ep=episode;if(ep==null)return;
            if(futureEpisode(ep)){if(downloadAction)planEpisode(ep);else Ui.toast(DetailsActivity.this,episodeDate(ep));return;}
            androidx.media3.exoplayer.offline.Download done=completed.get(DownloadHub.episodeKey(ep.number));
            if(done!=null)Ui.openOffline(DetailsActivity.this,done.request.id,anime,ep.number);
            else if(downloadAction)DownloadActions.prepare(DetailsActivity.this,anime,null,ep.number);
            else openWatch(ep.number,"yoru");
        }
        void bind(Anime.Episode ep) {
            episode=ep;boolean future=futureEpisode(ep);
            boolean current=Math.abs(progressCached.optDouble("episode",-9999)-ep.number)<0.001;
            String name=YoruApp.app().store.spoilerSafe()?"":ep.name;
            title.setText((current?"▶ ":"")+"Серия "+Ui.number(ep.number)+(name.isEmpty()?"":" · "+name));title.setTextColor(current?Ui.PURPLE:Ui.TEXT);
            subtitle.setText(future?episodeDate(ep):(ep.duration>0?Ui.time(ep.duration):"Доступна"));
            String poster=future?"":episodePoster(ep);
            shot.setVisibility(poster.isEmpty()?View.GONE:View.VISIBLE);
            placeholder.setVisibility(poster.isEmpty()?View.VISIBLE:View.GONE);
            placeholder.setText(future?episodeDate(ep):"Серия\n"+Ui.number(ep.number));play.setVisibility(future?View.GONE:View.VISIBLE);
            String key=anime.key()+":"+ep.number+":"+poster;
            if(!key.equals(imageKey)) {
                imageKey=key;shot.setTag(null);shot.setImageDrawable(null);
                if(!poster.isEmpty())YoruApp.app().images.load(shot,poster,key);
            }
            boolean done=completed.containsKey(DownloadHub.episodeKey(ep.number));
            download.setText(future?"Скачать\nпосле выхода":done?"Скачана":"Скачать\n"+downloadVoiceName());
            download.setEnabled(true);download.setAlpha(1f);
            download.setContentDescription((future?"Скачать после выхода, серия ":"Скачать серию ")+Ui.number(ep.number));
        }
    }
    private LinearLayout card(){LinearLayout c=Ui.column(this);c.setPadding(Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,14),Ui.dp(this,14));c.setBackground(Ui.stroke(Ui.CARD,14,this));return c;}

    private void richCard(LinearLayout body){ArrayList<String[]> rows=new ArrayList<>();addRich(rows,"Студия",anime.studio);addRich(rows,"Страна",anime.countries);addRich(rows,"Премьера",anime.airedDate);if(anime.durationMinutes>0)addRich(rows,"Серия",anime.durationMinutes+" мин");if(anime.translationsCount>0)addRich(rows,"Озвучки",String.valueOf(anime.translationsCount));addRich(rows,"Рейтинги",anime.ratings);int q=maxQuality(anime);addRich(rows,"Разрешение",q>0?QualityPlus.name(q):"будет проверено в плеере");if(!anime.franchise.isEmpty()||anime.shikimoriOrder>0)addRich(rows,"Франшиза",(anime.franchise.isEmpty()?"порядок":anime.franchise)+(anime.shikimoriOrder>0?" · #"+anime.shikimoriOrder:""));addRich(rows,"Медиа",(anime.screenshots.isEmpty()?"скриншотов нет":anime.screenshots.size()+" скриншотов")+(ApiRepository.safeUrl(anime.trailerUrl).isEmpty()?"":" · трейлер"));addRich(rows,"Папки",YoruApp.app().store.folderSummary(anime));addRich(rows,"Любимые озвучки",YoruApp.app().store.favoriteVoiceSummary());if(rows.isEmpty()&&anime.cast.isEmpty()&&anime.crew.isEmpty())return;Ui.space(body,16);LinearLayout c=card();c.addView(Ui.text(this,"Подробнее",17,Ui.TEXT,true));Ui.space(c,10);for(String[] row:rows){TextView t=Ui.text(this,row[0]+": "+row[1],11,Ui.MUTED,false);t.setLineSpacing(Ui.dp(this,3),1);c.addView(t);Ui.space(c,6);}if(!anime.crew.isEmpty()){TextView t=Ui.text(this,anime.crew,11,0xffc8b8d6,false);t.setLineSpacing(Ui.dp(this,3),1);c.addView(t);Ui.space(c,6);}if(!anime.cast.isEmpty()){TextView t=Ui.text(this,"Актёры: "+anime.cast,11,0xffc8b8d6,false);t.setLineSpacing(Ui.dp(this,3),1);c.addView(t);}body.addView(c);}
    private void addRich(ArrayList<String[]> rows,String key,String value){String v=value==null?"":value.trim();if(!v.isEmpty()&&!v.equals("0"))rows.add(new String[]{key,v});}
    private int maxQuality(Anime anime){int quality=0;if(anime!=null)for(Anime.Episode episode:EpisodeRules.visible(anime,anime.episodeList))if(!episode.future)for(Map.Entry<Integer,String> stream:episode.streams.entrySet())if(stream.getKey()!=null&&stream.getKey()>0&&stream.getKey()<=4320&&!ApiRepository.safeUrl(stream.getValue()).isEmpty())quality=Math.max(quality,stream.getKey());return quality;}

    private void about(LinearLayout body){Ui.space(body,24);body.addView(Ui.text(this,"Об истории",21,Ui.TEXT,true));Ui.space(body,13);if(YoruApp.app().store.spoilerSafe()&&!anime.description.isEmpty()){LinearLayout c=card();c.addView(Ui.text(this,"Описание скрыто режимом без спойлеров.",12,Ui.MUTED,false));Ui.space(c,9);c.addView(Ui.button(this,"Показать описание",false,()->{YoruApp.app().store.smartSetting("spoilerSafe",false);render();}));body.addView(c);return;}TextView description=Ui.text(this,anime.description.isEmpty()?"Описание пока недоступно.":anime.description,14,0xffc8b8d6,false);description.setLineSpacing(Ui.dp(this,5),1);body.addView(description);}
    private void trailer(){try{String url=ApiRepository.safeUrl(anime.trailerUrl);if(url.isEmpty())url="https://www.youtube.com/results?search_query="+Uri.encode(YoruBrain.title(anime)+" trailer");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Ui.toast(this,"Не удалось открыть трейлер");}}
    private void similar(LinearLayout body){ArrayList<Anime> rows=YoruBrain.similar(anime,8);if(rows.isEmpty())return;Ui.space(body,26);body.addView(Ui.text(this,"Похожее",21,Ui.TEXT,true));Ui.space(body,12);HorizontalScrollView row=new HorizontalScrollView(this);row.setHorizontalScrollBarEnabled(false);LinearLayout list=Ui.row(this);for(Anime a:rows){LinearLayout item=Ui.column(this);item.setPadding(0,0,Ui.dp(this,10),0);Ui.Card card=new Ui.Card(this,160);card.bind(a);item.addView(card,Ui.lp(this,132,-2));list.addView(item);}row.addView(list);body.addView(row,Ui.lp(this,-1,-2));}
    private void related(LinearLayout body){if(anime.related.isEmpty())return;ArrayList<Anime> rows=filteredRelated();Ui.space(body,27);LinearLayout title=Ui.row(this);title.addView(Ui.text(this,"Связанные аниме и фильмы",21,Ui.TEXT,true),new LinearLayout.LayoutParams(0,-2,1));Anime next=nextFranchise();if(next!=null){TextView cont=Ui.text(this,franchiseEnded()?"Продолжить":"Дальше",10,Ui.PURPLE,true);cont.setPadding(Ui.dp(this,9),Ui.dp(this,7),Ui.dp(this,9),Ui.dp(this,7));cont.setBackground(Ui.stroke(Ui.SURFACE,10,this));Ui.press(cont);cont.setOnClickListener(v->Ui.openDetails(this,next));title.addView(cont);}body.addView(title);Ui.space(body,10);body.addView(Ui.button(this,"Смотреть по порядку франшизу",false,()->{ArrayList<Anime> seq=franchiseSequence();if(!seq.isEmpty())Ui.openDetails(this,seq.get(0));}),Ui.lp(this,-1,-2));Ui.space(body,10);HorizontalScrollView wrap=new HorizontalScrollView(this);wrap.setHorizontalScrollBarEnabled(false);LinearLayout chips=Ui.row(this);String[][] fs={{"","Все"},{"season","Сезоны"},{"film","Фильмы"},{"ova","OVA"},{"special","Спешлы"}};for(String[] f:fs){TextView chip=Ui.chip(this,f[1],f[0].equals(relatedFilter),()->{relatedFilter=f[0];render();});LinearLayout.LayoutParams lp=Ui.lp(this,-2,-2);lp.rightMargin=Ui.dp(this,7);chips.addView(chip,lp);}wrap.addView(chips);body.addView(wrap,Ui.lp(this,-1,-2));Ui.space(body,12);if(rows.isEmpty()){LinearLayout c=card();c.addView(Ui.text(this,"В этом фильтре пока пусто.",12,Ui.MUTED,false));body.addView(c);return;}for(Anime a:rows){LinearLayout row=Ui.row(this);row.setPadding(Ui.dp(this,13),Ui.dp(this,11),Ui.dp(this,13),Ui.dp(this,11));row.setBackground(Ui.stroke(Ui.CARD,15,this));ImageView poster=new ImageView(this);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setClipToOutline(true);poster.setBackground(Ui.shape(Ui.SURFACE,12,this));row.addView(poster,Ui.lp(this,48,68));YoruApp.app().images.load(poster,a);String when=a.airedDate==null||a.airedDate.isEmpty()?a.meta():(a.airedDate+" · "+a.type);TextView text=Ui.text(this,a.title+"\n"+when,12,Ui.TEXT,false);text.setPadding(Ui.dp(this,12),0,0,0);row.addView(text,new LinearLayout.LayoutParams(0,-2,1));Ui.Icon icon=new Ui.Icon(this,"play");icon.color=Ui.PURPLE;row.addView(icon,Ui.lp(this,24,24));Ui.press(row);row.setOnClickListener(v->Ui.openDetails(this,a));body.addView(row);Ui.space(body,9);}}
    private ArrayList<Anime> filteredRelated(){ArrayList<Anime> out=new ArrayList<>();for(Anime a:anime.related){String t=(a.type==null?"":a.type).toLowerCase(Locale.ROOT);boolean film=t.contains("фильм")||t.contains("movie");boolean ova=t.contains("ova");boolean special=t.contains("спеш")||t.contains("special");boolean season=!film&&!ova&&!special;if(relatedFilter.isEmpty()||"film".equals(relatedFilter)&&film||"ova".equals(relatedFilter)&&ova||"special".equals(relatedFilter)&&special||"season".equals(relatedFilter)&&season)out.add(a);}out.sort(this::franchiseCompare);return out;}
    private ArrayList<Anime> franchiseSequence(){LinkedHashMap<String,Anime> map=new LinkedHashMap<>();if(Anime.valid(anime))map.put(SourceEngine.identity(anime),anime);for(Anime a:anime.related)if(Anime.valid(a))map.put(SourceEngine.identity(a),a);ArrayList<Anime> rows=new ArrayList<>(map.values());rows.sort(this::franchiseCompare);return rows;}
    private Anime nextFranchise(){ArrayList<Anime> rows=franchiseSequence();String own=SourceEngine.identity(anime);for(int i=0;i<rows.size();i++)if(SourceEngine.identity(rows.get(i)).equals(own)&&i+1<rows.size())return rows.get(i+1);return null;}
    private boolean franchiseEnded(){return EpisodeRules.completed(anime,progressCached.optDouble("episode",0),progressCached.optInt("time",0),progressCached.optInt("duration",0));}
    private int franchiseCompare(Anime a,Anime b){int p=releaseOrder(a)-releaseOrder(b);if(p!=0)return p;p=kindRank(a)-kindRank(b);if(p!=0)return p;p=seasonNo(a)-seasonNo(b);if(p!=0)return p;return YoruBrain.title(a).compareToIgnoreCase(YoruBrain.title(b));}
    private int releaseOrder(Anime a){if(a==null)return 99999999;if(a.airedDate!=null&&a.airedDate.length()>=4)try{return Integer.parseInt(a.airedDate.substring(0,4))*10000+monthDay(a.airedDate);}catch(Exception ignored){}return a.year>0?a.year*10000:99999999;}
    private int monthDay(String d){try{return Integer.parseInt(d.substring(5,7))*100+Integer.parseInt(d.substring(8,10));}catch(Exception e){return 0;}}
    private int kindRank(Anime a){String t=(a==null?"":a.type).toLowerCase(Locale.ROOT);if(t.contains("тв")||t.contains("tv"))return 10;if(t.contains("ona"))return 30;if(t.contains("фильм")||t.contains("movie"))return 50;if(t.contains("ova"))return 60;if(t.contains("спеш")||t.contains("special"))return 70;return 40;}
    private int seasonNo(Anime a){String t=((a==null?"":a.title)+" "+(a==null?"":a.original)).toLowerCase(Locale.ROOT);java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?:season|сезон)\\s*(\\d+)|(\\d+)\\s*(?:st|nd|rd|th|й|я)?\\s*сезон").matcher(t);if(m.find()){String n=m.group(1)!=null?m.group(1):m.group(2);try{return Integer.parseInt(n);}catch(Exception ignored){}}if(t.contains("iii"))return 3;if(t.contains("ii"))return 2;if(t.contains("iv"))return 4;return 1;}
    private void prefetchRelated(){if(anime==null||anime.related.isEmpty())return;ArrayList<Anime> rows=new ArrayList<>(anime.related.subList(0,Math.min(24,anime.related.size())));YoruApp.app().discovery.execute(()->{try{YoruApp.app().api.prefetchQuickDetails(rows,rows.size());}catch(Exception ignored){}});}
    private String airText(String raw){String value=raw==null?"":raw.trim();if(value.isEmpty()||value.equals("null"))return "дата уточняется";try{long instant=java.time.OffsetDateTime.parse(value).toInstant().toEpochMilli();java.time.ZoneId zone=ScheduleClock.zone(YoruApp.app().store.localScheduleTime());return ScheduleClock.format(instant,"d MMM",zone)+", "+ScheduleClock.time(instant,zone);}catch(Exception ignored){return value.replace('T',' ');}}

    private int playableCount(Collection<Anime.Episode> rows){int n=0;if(rows!=null)for(Anime.Episode e:rows)if(e!=null&&!e.future)n++;return n;}
    private String episodeKey(double n){return n==Math.floor(n)?String.valueOf((int)Math.floor(n)):String.valueOf(n);}
    private void prepareEpisodeDisplay(){displayedEpisodes.clear();if(anime==null)return;displayedEpisodes.addAll(EpisodeRules.visible(anime,anime.episodeList));HashSet<String> have=new HashSet<>();for(Anime.Episode episode:displayedEpisodes)have.add(episodeKey(episode.number));int total=anime.totalEpisodes(),aired=anime.aired();if(anime.ongoing()&&total>aired){for(int number=aired+1;number<=Math.min(total,aired+24);number++){if(have.contains(episodeKey(number)))continue;Anime.Episode future=new Anime.Episode();future.id=anime.id+"-future-"+number;future.number=number;markFutureLocal(future,futureText(number,aired));displayedEpisodes.add(future);}}displayedEpisodes.sort(Comparator.comparingDouble(episode->episode.number));}

    private void markFutureLocal(Anime.Episode ep,String label){ep.future=true;ep.airDate=label;ep.name=label;ep.poster="";ep.lazy="";ep.resolverUrl="";ep.duration=0;ep.streams.clear();ep.variants.clear();}
    private String futureText(int number,int aired){return number==aired+1&&!anime.nextEpisodeAt.isEmpty()?airText(anime.nextEpisodeAt):"Не вышла";}
    private String availableVoices(){LinkedHashMap<String,String> map=new LinkedHashMap<>();for(Anime.Episode e:anime.episodeList){if(e==null||e.future)continue;if(!e.streams.isEmpty()){String direct=ApiRepository.sourceVoice(anime.source);if(!direct.isEmpty())map.put(ApiRepository.voiceKey(direct),direct);}for(Anime.Variant v:e.variants){String title=ApiRepository.voiceTitle(v.name.isEmpty()?v.label():v.name);String key=ApiRepository.voiceKey(title);if(!key.isEmpty()&&!map.containsKey(key))map.put(key,title);if(map.size()>=5)break;}if(map.size()>=5)break;}StringBuilder b=new StringBuilder();for(String v:map.values()){if(b.length()>0)b.append(" · ");b.append(v);}return b.toString();}
    private String topLabel(){String v=availableVoices();if(v.isEmpty())return "YORU";return v.length()>34?v.substring(0,33).trim()+"…":v;}
    private String episodePoster(Anime.Episode ep){String p=ep==null?"":ApiRepository.safeUrl(ep.poster);if(!p.isEmpty())return p;if(!anime.screenshots.isEmpty()&&ep!=null)return anime.screenshots.get(Math.abs((int)Math.floor(ep.number)-1)%anime.screenshots.size());return "";}
    private boolean readyVoice(double number){SecureStore store=YoruApp.app().store;String pref=store.voicePreference(anime);if(!ApiRepository.voiceKey(pref).isEmpty()||!store.favoriteVoices().isEmpty())return true;JSONObject h=progressCached;String d=ApiRepository.voiceTitle(h.optString("dubbing",""));if(!d.isEmpty()&&Math.abs(h.optDouble("episode",-9999)-number)<0.001){store.voicePreference(anime,d);store.rememberVoice(d);return true;}return false;}
    private void screenshots(LinearLayout body){if(anime.screenshots.isEmpty())return;Ui.space(body,24);body.addView(Ui.text(this,"Скриншоты",21,Ui.TEXT,true));Ui.space(body,12);HorizontalScrollView row=new HorizontalScrollView(this);row.setHorizontalScrollBarEnabled(false);LinearLayout list=Ui.row(this);for(int i=0;i<Math.min(12,anime.screenshots.size());i++){FrameLayout frame=new FrameLayout(this);frame.setBackground(Ui.shape(Ui.CARD,15,this));frame.setClipToOutline(true);ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);frame.addView(img,new FrameLayout.LayoutParams(-1,-1));String url=anime.screenshots.get(i);YoruApp.app().images.load(img,url,anime.key()+":shot:"+i);final String open=url;frame.setOnClickListener(v->Ui.openImage(this,open,YoruBrain.title(anime)));Ui.press(frame);LinearLayout.LayoutParams lp=Ui.lp(this,194,109);lp.rightMargin=Ui.dp(this,9);list.addView(frame,lp);}row.addView(list);body.addView(row,Ui.lp(this,-1,-2));}
    private void trailerBlock(LinearLayout body){Ui.space(body,24);body.addView(Ui.text(this,"Трейлер",21,Ui.TEXT,true));Ui.space(body,12);String url=ApiRepository.safeUrl(anime.trailerUrl);if(url.isEmpty()){LinearLayout c=card();c.addView(Ui.text(this,"Прямой трейлер пока не найден. Можно открыть поиск трейлера по названию.",12,Ui.MUTED,false));Ui.space(c,10);c.addView(Ui.button(this,"Найти трейлер",false,this::trailer));body.addView(c);return;}body.addView(Ui.button(this,"Смотреть трейлер",false,this::trailer),Ui.lp(this,-1,-2));}
    private String ratingLine(){return anime!=null&&anime.ratingScore()>0?String.format(Locale.US,"★ %.1f",anime.ratingScore()):"рейтинг уточняется";}
    private String defaultVoiceName(){String title=ApiRepository.voiceTitle(YoruApp.app().store.voicePreference(anime));return title.isEmpty()?(YoruApp.app().store.favoriteVoices().isEmpty()?"Авто":"Любимые"):title;}
    private String downloadVoiceName(){String title=ApiRepository.voiceTitle(YoruApp.app().store.voicePreference(anime));return title.isEmpty()?(YoruApp.app().store.favoriteVoices().isEmpty()?"выбор озвучки":"любимые"):title;}
    private void voiceInfoCard(LinearLayout body){LinearLayout row=Ui.row(this);row.setPadding(Ui.dp(this,13),Ui.dp(this,10),Ui.dp(this,13),Ui.dp(this,10));row.setBackground(Ui.stroke(Ui.CARD,14,this));String available=availableVoices();String label=(!available.isEmpty()?"Доступные озвучки: "+available:(YoruApp.app().store.onlyPreferredVoice()&&!ApiRepository.voiceKey(YoruApp.app().store.voicePreference(anime)).isEmpty()?"Только озвучка: "+defaultVoiceName():"Любимые озвучки: "+YoruApp.app().store.favoriteVoiceSummary()))+" · "+ratingLine()+" · Разрешение: "+qualityName(YoruApp.app().store.quality());TextView text=Ui.text(this,label,11,Ui.TEXT,false);text.setLineSpacing(Ui.dp(this,3),1);row.addView(text,new LinearLayout.LayoutParams(0,-2,1));TextView edit=Ui.text(this,"Изменить",10,Ui.PURPLE,true);edit.setPadding(Ui.dp(this,10),Ui.dp(this,8),Ui.dp(this,10),Ui.dp(this,8));edit.setBackground(Ui.stroke(Ui.SURFACE,10,this));Ui.press(edit);edit.setOnClickListener(v->watchDefaults());row.addView(edit);body.addView(row);}
    private void openWatch(double number,String playMode){if(anime.blocked)return;androidx.media3.exoplayer.offline.Download done=completed.get(DownloadHub.episodeKey(number));if(done!=null){Ui.openOffline(this,done.request.id,anime,number);return;}if(readyVoice(number)){Ui.openPlayer(this,anime,"yoru",number);return;}chooseWatchVoice(number,playMode);}
    private void cancelWatchPreparation(){watchGeneration++;watchTasks.cancel();if(watchProgress!=null){watchProgress.dismiss();watchProgress=null;}}
    private void chooseWatchVoice(double number,String playMode){
        cancelWatchPreparation();int token=watchGeneration;Anime selected=snapshot(anime);
        Ui.Progress wait=Ui.progress(this,"Загружаем озвучки серии "+Ui.number(number)+"…",true,this::cancelWatchPreparation);if(!wait.isShowing())return;watchProgress=wait;
        watchTasks.submit(YoruApp.app().io,()->{
            try{WatchPack pack=watchPack(selected,number);TaskQueue.check();YoruApp.app().main.post(()->{
                if(dead()||token!=watchGeneration||!selected.key().equals(anime.key()))return;
                watchProgress=null;wait.dismiss();showWatchDialog(pack,playMode);
            });}catch(Exception error){YoruApp.app().main.post(()->{
                if(dead()||token!=watchGeneration||!selected.key().equals(anime.key()))return;
                watchProgress=null;wait.dismiss();Ui.confirm(this,"Озвучки пока не загрузились","Можно открыть просмотр или попробовать ещё раз.","Открыть",()->Ui.openPlayer(this,selected,"yoru",number),"Отмена");
            });}
        },()->{if(token==watchGeneration){watchProgress=null;wait.dismiss();Ui.toast(this,"Очередь занята. Повторите позже.");}});
    }
    private WatchPack watchPack(Anime target,double number)throws Exception{Anime.Playback ready=YoruApp.app().api.playback(target,"yoru");Anime.Episode ep=findEpisode(ready==null?null:ready.video,number);if(ep==null)throw new java.io.IOException();YoruApp.app().api.loadEpisode(ep);TaskQueue.check();LinkedHashMap<String,String> voices=new LinkedHashMap<>();boolean unknown=false;if(ep!=null){String direct=ready!=null&&ready.video!=null?ApiRepository.sourceVoice(ready.video.source):"";if(!direct.isEmpty()&&!ep.streams.isEmpty())voices.put(ApiRepository.voiceKey(direct),direct);for(Anime.Variant v:SourceEngine.sortVariants(ep.variants)){String title=ApiRepository.voiceTitle(v.name.isEmpty()?v.label():v.name);String key=ApiRepository.voiceKey(title);if(!key.isEmpty()&&!voices.containsKey(key))voices.put(key,title);else if(key.isEmpty()&&!ApiRepository.embed(v.url).isEmpty())unknown=true;}}ArrayList<String> names=new ArrayList<>(),values=new ArrayList<>();names.add("Авто · лучшая доступная");values.add("");for(String title:voices.values()){names.add(title);values.add(title);}if(names.size()==1&&unknown)names.set(0,"Авто · дорожка без названия");SecureStore store=YoruApp.app().store;String pref=store.voicePreference(target);VoiceOptions.retainPreferred(names,values,pref);int selected=0;for(int i=1;i<values.size();i++){if(ApiRepository.voiceMatches(pref,values.get(i)))selected=i;else if(selected==0&&store.voicePriority(values.get(i))>=0)selected=i;}WatchPack pack=new WatchPack();pack.playback=ready;pack.episode=ep;pack.names=names.toArray(new String[0]);pack.values=values.toArray(new String[0]);pack.selected=selected;return pack;}
    private Anime.Episode findEpisode(Anime source,double number){if(source==null)return null;for(Anime.Episode ep:source.episodeList)if(ep!=null&&!ep.future&&Math.abs(ep.number-number)<.001)return ep;return null;}
    private void showWatchDialog(WatchPack pack,String playMode){double number=pack.episode==null?progressCached.optDouble("episode",1):pack.episode.number;LinearLayout col=Ui.column(this);col.setPadding(Ui.dp(this,4),0,Ui.dp(this,4),0);TextView note=Ui.text(this,"Выберите озвучку и разрешение один раз. Следующие запуски этой серии откроются сразу.",12,Ui.MUTED,false);note.setLineSpacing(Ui.dp(this,4),1);col.addView(note);Ui.space(col,12);col.addView(Ui.text(this,"Озвучка",11,Ui.MUTED,false));Spinner voice=new Spinner(this);voice.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,pack.names));voice.setSelection(Math.max(0,Math.min(pack.selected,pack.names.length-1)));col.addView(voice,Ui.lp(this,-1,46));Ui.space(col,10);col.addView(Ui.text(this,"Разрешение",11,Ui.MUTED,false));Spinner quality=new Spinner(this);quality.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,QualityPlus.LABELS));quality.setSelection(qualityIndex(YoruApp.app().store.quality()));col.addView(quality,Ui.lp(this,-1,46));Ui.space(col,8);TextView current=Ui.text(this,"Сейчас: "+defaultVoiceName()+" · "+qualityName(YoruApp.app().store.quality()),10,Ui.PURPLE,false);col.addView(current);Ui.custom(this,"Серия "+Ui.number(number),col,"Смотреть",()->{String selected=pack.values[voice.getSelectedItemPosition()];int[] qualities=QualityPlus.values();YoruApp.app().store.settings(qualities[quality.getSelectedItemPosition()],YoruApp.app().store.autoNext());applyVoice(selected);Ui.openPlayer(this,anime,"yoru",number);},"Скачать",()->{String selected=pack.values[voice.getSelectedItemPosition()];int[] qualities=QualityPlus.values();YoruApp.app().store.settings(qualities[quality.getSelectedItemPosition()],YoruApp.app().store.autoNext());applyVoice(selected);DownloadActions.prepare(this,anime,pack.playback,number);render();},"Отмена");}
    private void applyVoice(String selected){String voice=selected==null?"":selected;YoruApp.app().store.voicePreference(anime,voice);if(!voice.isEmpty()){YoruApp.app().store.rememberVoice(voice);Ui.toast(this,"Озвучка добавлена в любимые: "+ApiRepository.voiceTitle(voice));}}
    private boolean dead(){return isFinishing()||isDestroyed();}
    private String qualityName(int q){return QualityPlus.name(q);}
    private int qualityIndex(int q){return QualityPlus.index(q);}
    private void watchDefaults(){LinearLayout col=Ui.column(this);col.setPadding(Ui.dp(this,4),0,Ui.dp(this,4),0);TextView fav=Ui.text(this,"Любимые озвучки: "+YoruApp.app().store.favoriteVoiceSummary()+"\nЛюбимые озвучки будут выше в списке. Строгий режим оставляет только выбранную.",11,Ui.MUTED,false);fav.setLineSpacing(Ui.dp(this,4),1);col.addView(fav);Ui.space(col,10);Spinner voice=new Spinner(this);VoiceOptions options=new VoiceOptions(YoruApp.app().store.voicePreference(anime));voice.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,options.names()));voice.setSelection(options.index());col.addView(Ui.text(this,"Озвучка по умолчанию",11,Ui.MUTED,false));col.addView(voice,Ui.lp(this,-1,46));Ui.space(col,10);Spinner quality=new Spinner(this);quality.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,QualityPlus.LABELS));quality.setSelection(qualityIndex(YoruApp.app().store.quality()));col.addView(Ui.text(this,"Разрешение по умолчанию",11,Ui.MUTED,false));col.addView(quality,Ui.lp(this,-1,46));Switch only=new Switch(this);only.setText("Открывать только выбранную озвучку");only.setTextColor(Ui.TEXT);only.setTextSize(13);only.setTypeface(Ui.typeface(this,false));only.setChecked(YoruApp.app().store.onlyPreferredVoice());col.addView(only,Ui.lp(this,-1,52));Ui.custom(this,"Просмотр",col,"Сохранить",()->{int[] qualities=QualityPlus.values();String value=options.value(voice.getSelectedItemPosition());YoruApp.app().store.voicePreference(anime,value);if(!value.isEmpty())YoruApp.app().store.rememberVoice(value);YoruApp.app().store.onlyPreferredVoice(only.isChecked()&&!value.isEmpty());YoruApp.app().store.settings(qualities[quality.getSelectedItemPosition()],YoruApp.app().store.autoNext());Ui.toast(this,"Просмотр обновлён");render();},null,null,"Отмена");}

    @Override protected void onSaveInstanceState(Bundle out){
        if(Anime.valid(anime))out.putString("selectedAnime",anime.json().toString());
        if(inlinePlayer!=null)out.putBundle("inlineState",inlinePlayer.saveState());
        super.onSaveInstanceState(out);
    }
    @Override protected void onPause(){cancelWatchPreparation();if(inlinePlayer!=null)inlinePlayer.suspend();super.onPause();}
    @Override protected void onDestroy(){cancelWatchPreparation();if(inlinePlayer!=null)inlinePlayer.close();generation++;downloadsGeneration++;if(detailFuture!=null)detailFuture.cancel(true);if(earlyPlayback!=null)earlyPlayback.cancel(true);if(downloadFuture!=null)downloadFuture.cancel(true);cardPool.shutdownNow();super.onDestroy();}
}
