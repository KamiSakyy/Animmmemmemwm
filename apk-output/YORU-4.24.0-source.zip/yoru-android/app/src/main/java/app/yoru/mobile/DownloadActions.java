package app.yoru.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class DownloadActions {
    private DownloadActions(){}
    private interface Loader {List<ApiRepository.DownloadOption> load()throws Exception;}
    private static final class VoicePack {Anime.Playback ready;String[] names,values;}
    public static void askEpisode(Activity activity,Anime anime,Anime.Playback current,double suggested){chooseEpisodeFast(activity,anime,current,suggested,null);}
    public static void chooseEpisode(Activity activity,Anime anime,Anime.Playback current,double suggested){chooseEpisodeFast(activity,anime,current,suggested,null);}
    public static void chooseEpisodeFast(Activity activity,Anime anime,Anime.Playback current,double suggested,List<Anime.Episode> known){
        if(known!=null&&!known.isEmpty()){Anime.Playback ready=new Anime.Playback();ready.catalog=anime;ready.video=anime;ready.provider=anime.source;showEpisodeChoice(activity,anime,ready,new ArrayList<>(known),suggested);return;}
        if(current!=null&&current.video!=null&&!current.video.episodeList.isEmpty()){showEpisodeChoice(activity,anime,current,new ArrayList<>(current.video.episodeList),suggested);return;}
        Anime selected=Anime.from(anime.json());TaskQueue.Signal cancelled=new TaskQueue.Signal();
        Ui.Progress wait=Ui.progress(activity,"Загружаем серии…",true,()->cancelled.set(true));
        TaskQueue.run(YoruApp.app().io,cancelled,()->{
            try{
                Anime.Playback ready=YoruApp.app().api.playback(selected,"yoru");TaskQueue.check();
                ArrayList<Anime.Episode> episodes=ready==null||ready.video==null?new ArrayList<>():new ArrayList<>(ready.video.episodeList);
                YoruApp.app().main.post(()->{if(dead(activity)||cancelled.get())return;wait.dismiss();showEpisodeChoice(activity,selected,ready,episodes,suggested);});
            }catch(Exception error){YoruApp.app().main.post(()->{if(!dead(activity)&&!cancelled.get()){wait.dismiss();Ui.toast(activity,"Список серий пока недоступен");}});}
        },()->{wait.dismiss();if(!dead(activity))Ui.toast(activity,"Очередь занята. Повторите позже.");});
    }
    private static void showEpisodeChoice(Activity activity,Anime anime,Anime.Playback ready,ArrayList<Anime.Episode> episodes,double suggested){ArrayList<Anime.Episode> visible=new ArrayList<>(EpisodeRules.visible(anime,episodes));episodes.clear();episodes.addAll(visible);if(episodes.isEmpty()){Ui.toast(activity,"Нет вышедших серий для скачивания");return;}String[] labels=labels(episodes);int index=closest(episodes,suggested);Ui.singleChoice(activity,"Выберите серию",labels,index,"Далее",i->{Anime.Episode ep=episodes.get(i);if(ep.future)ScheduledDownloads.choose(activity,anime,ep.number,0,ep.airDate);else prepare(activity,anime,ready,ep.number);});}
    public static void chooseBatch(Activity activity,Anime anime,Anime.Playback current,double suggested){chooseBatchFast(activity,anime,current,suggested,null);}
    public static void chooseBatchFast(Activity activity,Anime anime,Anime.Playback current,double suggested,List<Anime.Episode> known){if((current==null||current.video==null||current.video.episodeList.isEmpty())&&known!=null&&!known.isEmpty()){Anime.Playback ready=new Anime.Playback();ready.catalog=anime;ready.video=anime;ready.provider=anime.source;showBatch(activity,anime,ready,new ArrayList<>(known),suggested);return;}TaskQueue.Signal cancelled=new TaskQueue.Signal();Ui.Progress wait=Ui.progress(activity,"Готовим серии…",true,()->cancelled.set(true));TaskQueue.run(YoruApp.app().io,cancelled,()->{try{Anime.Playback ready=current;if(ready==null||ready.video==null||ready.video.episodeList.isEmpty())ready=YoruApp.app().api.playback(anime,"yoru");Anime.Playback finalReady=ready;ArrayList<Anime.Episode> episodes=new ArrayList<>(ready.video.episodeList);YoruApp.app().main.post(()->{if(dead(activity)||cancelled.get())return;wait.dismiss();if(episodes.isEmpty()){Ui.toast(activity,"Список серий пока недоступен");return;}showBatch(activity,anime,finalReady,episodes,suggested);});}catch(Exception e){YoruApp.app().main.post(()->{if(!dead(activity)&&!cancelled.get()){wait.dismiss();Ui.toast(activity,"Не удалось загрузить список серий");}});}},()->{wait.dismiss();Ui.toast(activity,"Очередь занята. Повторите действие позже.");});}
    public static void prepare(Activity activity,Anime anime,Anime.Playback current,double episode){loadVoiceDialog(activity,anime,current,episode);}
    public static void prepareNativeCurrent(Activity activity,Anime anime,Anime.Playback current,double number,Anime.Episode episode,String voice,String player){prepareNativeCurrent(activity,anime,current,number,episode,episode==null?Collections.emptyMap():episode.streams,voice,player);}
    public static void prepareNativeCurrent(Activity activity,Anime anime,Anime.Playback current,double number,Anime.Episode episode,Map<Integer,String> streams,String voice,String player){
        if(episode==null)return;
        Anime.Episode selected=new Anime.Episode();selected.id=episode.id;selected.number=episode.number;selected.name=episode.name;selected.duration=episode.duration;selected.future=episode.future;selected.streams.putAll(streams);
        loadAndShow(activity,anime,number,"Готовим текущую озвучку…","Текущую озвучку пока нельзя сохранить.",()->merge(nativeOptions(anime,number,selected,voice,player)));
    }
    private static void loadVoiceDialog(Activity activity,Anime anime,Anime.Playback current,double episode){TaskQueue.Signal cancelled=new TaskQueue.Signal();Ui.Progress wait=Ui.progress(activity,"Открываем серию…",true,()->cancelled.set(true));TaskQueue.run(YoruApp.app().io,cancelled,()->{try{VoicePack pack=voicePack(anime,current,episode);YoruApp.app().main.post(()->{if(dead(activity)||cancelled.get())return;wait.dismiss();filterDialog(activity,anime,pack.ready,episode,pack);});}catch(Exception e){YoruApp.app().main.post(()->{if(!dead(activity)&&!cancelled.get()){wait.dismiss();Ui.toast(activity,"Не удалось загрузить доступные озвучки");}});}},()->{wait.dismiss();Ui.toast(activity,"Очередь занята. Повторите действие позже.");});}
    private static VoicePack voicePack(Anime anime,Anime.Playback current,double episode)throws Exception{Anime.Playback ready=current;if(ready==null||ready.video==null||ready.video.episodeList.isEmpty())ready=YoruApp.app().api.playback(anime,"yoru");LinkedHashMap<String,String> voices=new LinkedHashMap<>();if(ready!=null&&ready.video!=null){Anime.Episode ep=findEpisode(ready.video,episode);if(ep==null)throw new java.io.IOException();YoruApp.app().api.loadEpisode(ep);TaskQueue.check();String direct=ApiRepository.sourceVoice(ready.video.source);if(ep!=null){for(Anime.Variant v:ep.variants){String title=ApiRepository.voiceTitle(v.name.isEmpty()?v.label():v.name);String key=ApiRepository.voiceKey(title);if(!key.isEmpty()&&!voices.containsKey(key))voices.put(key,title);}if(!direct.isEmpty()&&!ep.streams.isEmpty())voices.put(ApiRepository.voiceKey(direct),direct);}}ArrayList<String> names=new ArrayList<>(),values=new ArrayList<>();names.add("Любая доступная");values.add("");for(String title:voices.values()){names.add(title);values.add(title);}VoiceOptions.retainPreferred(names,values,YoruApp.app().store.voicePreference(anime));VoicePack pack=new VoicePack();pack.ready=ready;pack.names=names.toArray(new String[0]);pack.values=values.toArray(new String[0]);return pack;}
    private static Anime.Episode findEpisode(Anime anime,double number){if(anime==null||!Double.isFinite(number))return null;for(Anime.Episode ep:anime.episodeList)if(ep!=null&&!ep.future&&Math.abs(ep.number-number)<.001)return ep;return null;}
    private static void filterDialog(Activity activity,Anime anime,Anime.Playback current,double episode,VoicePack pack){LinearLayout col=Ui.column(activity);col.setPadding(Ui.dp(activity,4),0,Ui.dp(activity,4),0);int voiceIndex=voiceIndex(YoruApp.app().store.voicePreference(anime),pack.values);Spinner voice=spinner(activity,col,"Озвучка",pack.names,voiceIndex);Switch strict=new Switch(activity);strict.setText("Показывать только выбранную озвучку");strict.setTextColor(Ui.TEXT);strict.setTextSize(13);strict.setTypeface(Ui.typeface(activity,false));strict.setChecked(YoruApp.app().store.onlyPreferredVoice()&&voiceIndex>0);col.addView(strict,Ui.lp(activity,-1,50));String[] qLabels=QualityPlus.LABELS_WITH_BEST;int[] qValues=QualityPlus.valuesWithBest();int q=YoruApp.app().store.downloadResolution(),qIndex=QualityPlus.indexWithBest(q);Spinner quality=spinner(activity,col,"Разрешение",qLabels,qIndex);TextView now=Ui.text(activity,"На кнопках сейчас: "+(voiceIndex>0?pack.names[voiceIndex]:"выбор озвучки"),10,Ui.PURPLE,false);col.addView(now);Ui.space(col,6);TextView note=Ui.text(activity,"Список относится к выбранной серии. Чтобы исключить другие озвучки, включите строгий фильтр. Итоговый вариант можно выбрать перед скачиванием.",10,Ui.MUTED,false);col.addView(note);Ui.custom(activity,"Скачивание серии "+Ui.number(episode),col,"Найти",()->{String selectedVoice=pack.values[voice.getSelectedItemPosition()];int selectedQuality=qValues[quality.getSelectedItemPosition()];boolean only=strict.isChecked()&&!selectedVoice.isEmpty();if(!selectedVoice.isEmpty()){YoruApp.app().store.voicePreference(anime,selectedVoice);YoruApp.app().store.rememberVoice(selectedVoice);}else YoruApp.app().store.voicePreference(anime,"");YoruApp.app().store.onlyPreferredVoice(only);YoruApp.app().store.downloadResolution(selectedQuality);loadAndShow(activity,anime,episode,"Ищем подходящую озвучку…","YORU не нашёл выбранную озвучку для сохранения этой серии. Измените фильтр или откройте серию и попробуйте текущую озвучку.",selectedQuality,()->YoruApp.app().api.downloadOptions(anime,current,episode,selectedVoice,selectedQuality,only));},null,null,"@close");}
    private static int voiceIndex(String value){return voiceIndex(value,ApiRepository.VOICE_PREF_VALUES);}
    private static int voiceIndex(String value,String[] values){String key=ApiRepository.voiceKey(value);for(int i=0;i<values.length;i++)if(ApiRepository.voiceKey(values[i]).equals(key))return i;return 0;}
    private static Spinner spinner(Activity activity,LinearLayout col,String title,String[] values,int initial){col.addView(Ui.text(activity,title,11,Ui.MUTED,false));Spinner s=new Spinner(activity);s.setAdapter(new ArrayAdapter<>(activity,android.R.layout.simple_spinner_dropdown_item,values));s.setSelection(Math.max(0,Math.min(values.length-1,initial)));col.addView(s,Ui.lp(activity,-1,45));Ui.space(col,8);return s;}
    private static void showBatch(Activity activity,Anime anime,Anime.Playback ready,ArrayList<Anime.Episode> episodes,double suggested){ArrayList<Anime.Episode> rows=EpisodeRules.downloadable(anime,episodes);if(rows.isEmpty()){Ui.toast(activity,"Нет вышедших серий для скачивания");return;}String[] presets={"Следующие 3 серии","Следующие 6 серий","Следующие 12 серий","Выбрать серии вручную"};Ui.choices(activity,"Массовое скачивание",presets,which->{if(which==3)multiBatch(activity,anime,ready,rows,suggested);else{int count=which==0?3:which==1?6:12;int start=closest(rows,suggested);ArrayList<Anime.Episode> selected=new ArrayList<>();for(int i=start;i<rows.size()&&selected.size()<count;i++)selected.add(rows.get(i));qualityBatch(activity,anime,ready,selected);}});}
    private static void multiBatch(Activity activity,Anime anime,Anime.Playback ready,ArrayList<Anime.Episode> episodes,double suggested){episodes.removeIf(e->e==null||e.future);if(episodes.isEmpty()){Ui.toast(activity,"Нет вышедших серий для скачивания");return;}String[] labels=labels(episodes);boolean[] checked=new boolean[episodes.size()];int start=closest(episodes,suggested);for(int i=0;i<episodes.size();i++)checked[i]=i>=start&&i<start+3;Ui.multiChoice(activity,"Выберите серии",labels,checked,"Разрешение",state->{ArrayList<Anime.Episode> selected=new ArrayList<>();for(int n=0;n<episodes.size();n++)if(state[n])selected.add(episodes.get(n));qualityBatch(activity,anime,ready,selected);});}
    private static void qualityBatch(Activity activity,Anime anime,Anime.Playback ready,ArrayList<Anime.Episode> episodes){episodes.removeIf(e->e==null||e.future);if(episodes.isEmpty()){Ui.toast(activity,"Нет вышедших серий для скачивания");return;}LinearLayout col=Ui.column(activity);col.setPadding(Ui.dp(activity,4),0,Ui.dp(activity,4),0);String currentVoice=YoruApp.app().store.voicePreference(anime);ArrayList<String> voiceNames=new ArrayList<>(Arrays.asList(ApiRepository.VOICE_PREF_NAMES)),voiceValues=new ArrayList<>(Arrays.asList(ApiRepository.VOICE_PREF_VALUES));if(!ApiRepository.voiceKey(currentVoice).isEmpty()&&voiceIndex(currentVoice)==0){voiceNames.add(currentVoice);voiceValues.add(currentVoice);}String[] savedValues=voiceValues.toArray(new String[0]);Spinner voice=spinner(activity,col,"Озвучка",voiceNames.toArray(new String[0]),voiceIndex(currentVoice,savedValues));Switch strict=new Switch(activity);strict.setText("Только выбранная озвучка");strict.setTextColor(Ui.TEXT);strict.setTextSize(13);strict.setTypeface(Ui.typeface(activity,false));strict.setChecked(YoruApp.app().store.onlyPreferredVoice());col.addView(strict,Ui.lp(activity,-1,50));String[] labels={"Как в настройках","360p или ниже","480p или ниже","720p или ниже","1080p или ниже","1440p · 2K или ниже","2160p · 4K или ниже","Лучшее доступное разрешение"};int[] values={-1,360,480,720,1080,1440,2160,QualityPlus.BEST};Spinner quality=spinner(activity,col,"Разрешение",labels,0);Ui.custom(activity,"Фильтры для "+episodes.size()+" серий",col,"Добавить",()->{String selectedVoice=savedValues[voice.getSelectedItemPosition()];boolean only=strict.isChecked()&&!selectedVoice.isEmpty();YoruApp.app().store.voicePreference(anime,selectedVoice);if(!selectedVoice.isEmpty())YoruApp.app().store.rememberVoice(selectedVoice);YoruApp.app().store.onlyPreferredVoice(only);startBatch(activity,anime,ready,episodes,values[quality.getSelectedItemPosition()],selectedVoice,only);},null,null,"@close");}
    private static void startBatch(Activity activity,Anime anime,Anime.Playback ready,ArrayList<Anime.Episode> episodes,int preferred,String voice,boolean strict){
        ArrayList<Anime.Episode> rows=EpisodeRules.downloadable(anime,episodes);if(rows.isEmpty()){Ui.toast(activity,"Нет вышедших серий для скачивания");return;}
        TaskQueue.Signal cancelled=new TaskQueue.Signal();Ui.Progress wait=Ui.progress(activity,"Готовим серии: 0 / "+rows.size(),true,()->cancelled.set(true));
        TaskQueue.run(YoruApp.app().io,cancelled,()->{
            final ApiRepository.DownloadOption[] chosenRows=new ApiRepository.DownloadOption[rows.size()];
            final long[] sizeRows=new long[rows.size()];
            final String[] formatRows=new String[rows.size()];
            final java.util.concurrent.atomic.AtomicInteger failedCount=new java.util.concurrent.atomic.AtomicInteger();
            final java.util.concurrent.atomic.AtomicInteger doneCount=new java.util.concurrent.atomic.AtomicInteger();
            java.util.concurrent.ExecutorService pool=TaskQueue.pool(Math.max(1,Math.min(6,rows.size())));
            ArrayList<java.util.concurrent.Future<?>> tasks=new ArrayList<>();
            for(int i=0;i<rows.size();i++){
                final int index=i;final Anime.Episode ep=rows.get(i);
                try{
                    tasks.add(pool.submit(()->{
                        try{
                            if(cancelled.get()||dead(activity))return;
                            int limit=preferred<0?YoruApp.app().store.downloadResolution():preferred;
                            ApiRepository.DownloadOption chosen=choose(YoruApp.app().api.downloadOptions(anime,ready,ep.number,voice,limit,strict),limit);
                            if(chosen==null||chosen.episode==null||chosen.episode.future||Double.compare(chosen.episode.number,ep.number)!=0||EpisodeRules.conflicts(anime,chosen.source)||(strict&&!ApiRepository.voiceMatches(voice,chosen.voice+" "+chosen.episode.name))){failedCount.incrementAndGet();return;}
                            MediaSize.Info info=MediaSize.probeInfo(chosen.episode.streams.get(chosen.quality),true);TaskQueue.check();
                            chosenRows[index]=chosen;sizeRows[index]=info.bytes;formatRows[index]=info.mime;
                        }catch(Exception error){if(!cancelled.get()&&!dead(activity))failedCount.incrementAndGet();}
                        finally{
                            int done=doneCount.incrementAndGet();
                            YoruApp.app().main.post(()->{if(!dead(activity)&&!cancelled.get())wait.setMessage("Готовим серии: "+done+" / "+rows.size());});
                        }
                    }));
                }catch(java.util.concurrent.RejectedExecutionException error){failedCount.incrementAndGet();}
            }
            for(java.util.concurrent.Future<?> task:tasks){try{task.get();}catch(Exception ignored){}}
            pool.shutdownNow();
            if(dead(activity)||cancelled.get())return;
            ArrayList<ApiRepository.DownloadOption> prepared=new ArrayList<>();ArrayList<Long> sizes=new ArrayList<>();ArrayList<String> formats=new ArrayList<>();
            for(int i=0;i<rows.size();i++)if(chosenRows[i]!=null){prepared.add(chosenRows[i]);sizes.add(sizeRows[i]);formats.add(formatRows[i]);}
            int missing=failedCount.get();YoruApp.app().main.post(()->{
                if(dead(activity)||cancelled.get())return;wait.dismiss();
                if(prepared.isEmpty()){Ui.toast(activity,"Доступных серий с выбранными условиями не найдено");return;}
                long total=MediaSize.total(sizes);StringBuilder text=new StringBuilder("Готово к скачиванию: ").append(prepared.size()).append("\n");
                text.append(total>0?"Общий размер: "+MediaSize.label(total):"Общий размер неизвестен: не все источники сообщили размер файла.");
                if(missing>0)text.append("\nНе найдено с выбранными условиями: ").append(missing);
                if(YoruApp.app().traffic.metered()&&!YoruApp.app().store.wifiDownloads())text.append("\nБудет использован мобильный интернет.");
                for(int i=0;i<Math.min(12,prepared.size());i++){ApiRepository.DownloadOption option=prepared.get(i);text.append("\n\nСерия ").append(Ui.number(option.episode.number)).append(" · ").append(option.label()).append("\n").append(MediaSize.label(sizes.get(i)));}
                if(prepared.size()>12)text.append("\n\nИ ещё ").append(prepared.size()-12).append(" серий.");
                ScrollView scroll=new ScrollView(activity);scroll.setLayoutParams(new LinearLayout.LayoutParams(-1,Ui.dp(activity,320)));scroll.addView(Ui.text(activity,text.toString(),13,Ui.MUTED,false));
                Ui.custom(activity,"Скачать выбранные серии?",scroll,"Скачать",()->{
                    if(dead(activity))return;
                    if(Build.VERSION.SDK_INT>=33&&activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4101);
                    for(int i=0;i<prepared.size();i++){ApiRepository.DownloadOption option=prepared.get(i);YoruApp.app().downloads().enqueue(anime,option.source,option.episode,option.quality,option.voice,formats.get(i));}
                },null,null,"@close");
            });
        },()->{wait.dismiss();if(!dead(activity))Ui.toast(activity,"Не удалось подготовить скачивание. Попробуйте ещё раз.");});
    }
    private static ApiRepository.DownloadOption choose(List<ApiRepository.DownloadOption> options,int preferred){if(options==null||options.isEmpty())return null;ApiRepository.DownloadOption best=null;if(preferred==9999){for(ApiRepository.DownloadOption o:options)if(best==null||o.quality>best.quality)best=o;return best==null?options.get(0):best;}int limit=preferred<0?(YoruApp.app().savingMobile()?360:YoruApp.app().store.quality()):preferred;for(ApiRepository.DownloadOption o:options)if(o.quality>0&&o.quality<=limit&&(best==null||o.quality>best.quality))best=o;return best;}
    private static void loadAndShow(Activity activity,Anime anime,double episode,String message,String empty,Loader loader){loadAndShow(activity,anime,episode,message,empty,-1,loader);}
    private static void loadAndShow(Activity activity,Anime anime,double episode,String message,String empty,int preferredQuality,Loader loader){TaskQueue.Signal cancelled=new TaskQueue.Signal();Ui.Progress wait=Ui.progress(activity,message,true,()->cancelled.set(true));TaskQueue.run(YoruApp.app().io,cancelled,()->{try{List<ApiRepository.DownloadOption> options=merge(loader.load());YoruApp.app().main.post(()->{if(dead(activity)||cancelled.get())return;wait.dismiss();if(options.isEmpty()){Ui.message(activity,"Нет доступного варианта",empty);return;}showOptions(activity,anime,episode,options,preferredQuality);});}catch(Exception e){YoruApp.app().main.post(()->{if(!dead(activity)&&!cancelled.get()){wait.dismiss();Ui.toast(activity,"Не удалось подготовить загрузку. Попробуйте другой вариант.");}});}},()->{wait.dismiss();Ui.toast(activity,"Очередь занята. Повторите действие позже.");});}
    private static void showOptions(Activity activity,Anime anime,double episode,List<ApiRepository.DownloadOption> options,int preferredQuality){
        ArrayList<ApiRepository.DownloadOption> rows=new ArrayList<>(options);if(rows.isEmpty())return;
        ArrayList<String> labels=new ArrayList<>();int preferred=preferredQuality>0?preferredQuality:(YoruApp.app().savingMobile()?480:YoruApp.app().store.quality()),index=0,best=-1;
        for(int i=0;i<rows.size();i++){labels.add(privateLabel(rows.get(i)));int q=rows.get(i).quality;if(preferred==9999){if(q>best){best=q;index=i;}}else if(q>0&&q<=preferred&&q>best){best=q;index=i;}}
        final int[] current={index};
        BaseAdapter adapter=new BaseAdapter(){
            public int getCount(){return labels.size();}
            public Object getItem(int p){return labels.get(p);}
            public long getItemId(int p){return p;}
            public android.view.View getView(int p,android.view.View old,android.view.ViewGroup parent){
                LinearLayout row=Ui.row(activity);row.setPadding(Ui.dp(activity,12),Ui.dp(activity,8),Ui.dp(activity,12),Ui.dp(activity,8));
                boolean on=current[0]==p;row.setBackground(on?Ui.shape(0x332f2144,14,activity):Ui.stroke(Ui.CARD,14,activity));
                TextView mark=Ui.text(activity,on?"✓":"",16,Ui.PURPLE,true);mark.setGravity(android.view.Gravity.CENTER);row.addView(mark,Ui.lp(activity,28,38));
                TextView label=Ui.text(activity,labels.get(p),13,on?Ui.TEXT:Ui.MUTED,true);label.setMaxLines(3);label.setEllipsize(android.text.TextUtils.TruncateAt.END);
                row.addView(label,new LinearLayout.LayoutParams(0,-2,1));return row;
            }
        };
        ListView list=new ListView(activity);list.setDivider(null);list.setCacheColorHint(android.graphics.Color.TRANSPARENT);list.setVerticalScrollBarEnabled(false);
        list.setBackgroundColor(android.graphics.Color.TRANSPARENT);list.setAdapter(adapter);
        list.setOnItemClickListener((parent,view,pos,id)->{current[0]=pos;adapter.notifyDataSetChanged();});
        list.setLayoutParams(new LinearLayout.LayoutParams(-1,Math.min(Ui.dp(activity,430),Ui.dp(activity,54*Math.max(1,Math.min(rows.size(),8))))));
        android.app.Dialog dialog=Ui.custom(activity,"Серия "+Ui.number(episode)+" · озвучка и разрешение",list,"Скачать",()->{int pick=Math.max(0,Math.min(rows.size()-1,current[0]));confirm(activity,anime,rows.get(pick));},null,null,"@close");
        TaskQueue.Signal cancelled=new TaskQueue.Signal();
        dialog.setOnDismissListener(ignored->cancelled.set(true));
        TaskQueue.run(YoruApp.app().io,cancelled,()->{
            int limit=Math.min(rows.size(),8);
            java.util.concurrent.ExecutorService pool=TaskQueue.pool(Math.max(1,Math.min(4,limit)));
            ArrayList<java.util.concurrent.Future<?>> tasks=new ArrayList<>();
            for(int i=0;i<limit;i++){
                final int slot=i;final ApiRepository.DownloadOption option=rows.get(slot);
                String url=option.episode==null?null:option.episode.streams.get(option.quality);
                if(url==null||url.isEmpty())continue;
                final String stream=url;
                try{
                    tasks.add(pool.submit(()->{
                        try{
                            if(cancelled.get())return;
                            long bytes=MediaSize.probeInfo(stream,true).bytes;
                            if(bytes<=0)return;
                            final String updated=option.label()+" · "+MediaSize.label(bytes);
                            YoruApp.app().main.post(()->{if(cancelled.get()||slot>=labels.size())return;labels.set(slot,updated);adapter.notifyDataSetChanged();});
                        }catch(Exception ignored){}
                    }));
                }catch(java.util.concurrent.RejectedExecutionException ignored){}
            }
            for(java.util.concurrent.Future<?> task:tasks){try{task.get();}catch(Exception ignored){}}
            pool.shutdownNow();
        },null);
    }
    private static List<ApiRepository.DownloadOption> nativeOptions(Anime anime,double number,Anime.Episode current,String voice,String player){ArrayList<ApiRepository.DownloadOption> out=new ArrayList<>();if(current==null||current.future||Math.abs(current.number-number)>.001||current.streams.isEmpty())return out;int n=0;for(Map.Entry<Integer,String> stream:current.streams.entrySet()){String safe=ApiRepository.safeUrl(stream.getValue());if(safe.isEmpty())continue;Anime source=Anime.from(anime.json());Anime.Episode ep=new Anime.Episode();ep.id="native-"+Integer.toUnsignedString((anime.key()+"|"+safe).hashCode())+"-"+Ui.number(number)+"-"+(++n);ep.number=number;ep.name=(voice==null||voice.isEmpty())?"Плеер YORU":voice;ep.streams.put(stream.getKey(),safe);out.add(new ApiRepository.DownloadOption(source,ep,stream.getKey(),ep.name,(player==null||player.isEmpty())?"Плеер YORU":"Плеер YORU · "+player));}return out;}
    private static String privateLabel(ApiRepository.DownloadOption option){return option.label();}

    private static ArrayList<ApiRepository.DownloadOption> merge(List<ApiRepository.DownloadOption> options){LinkedHashMap<String,ApiRepository.DownloadOption> map=new LinkedHashMap<>();if(options!=null)for(ApiRepository.DownloadOption option:options){if(option==null||option.source==null||option.episode==null)continue;String url=option.episode.streams.get(option.quality);String safe=ApiRepository.safeUrl(url);if(safe.isEmpty())continue;String voice=ApiRepository.voiceKey(option.voice+" "+option.episode.name);String key=Ui.number(option.episode.number)+"|"+option.quality+"|"+(voice.isEmpty()?"unknown:"+Integer.toHexString(safe.hashCode()):voice);if(!map.containsKey(key))map.put(key,option);}return new ArrayList<>(map.values());}
    private static void confirm(Activity activity,Anime anime,ApiRepository.DownloadOption option){
        if(option==null||option.episode==null||dead(activity))return;
        String url=option.episode.streams.get(option.quality);
        TaskQueue.Signal cancelled=new TaskQueue.Signal();Ui.Progress wait=Ui.progress(activity,"Уточняем размер…",true,()->cancelled.set(true));
        TaskQueue.run(YoruApp.app().ui,cancelled,()->{
            MediaSize.Info info=MediaSize.probeInfo(url,true);long bytes=info.bytes;
            YoruApp.app().main.post(()->{
                if(dead(activity)||cancelled.get())return;wait.dismiss();
                boolean mobile=YoruApp.app().traffic.metered()&&!YoruApp.app().store.wifiDownloads();
                String message=option.label()+"\n"+(bytes>0?"Размер файла: "+MediaSize.label(bytes):"Источник не сообщает точный размер. Он станет известен после скачивания.");
                if(mobile)message+="\nБудет использован мобильный интернет.";
                Ui.confirm(activity,"Скачать серию "+Ui.number(option.episode.number)+"?",message,"Скачать",()->{
                    if(dead(activity))return;
                    if(Build.VERSION.SDK_INT>=33&&activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4101);
                    YoruApp.app().downloads().enqueue(anime,option.source,option.episode,option.quality,option.voice,info.mime);
                },"Не сейчас");
            });
        },()->{wait.dismiss();if(!dead(activity))Ui.toast(activity,"Не удалось подготовить скачивание. Попробуйте ещё раз.");});
    }
    private static String[] labels(ArrayList<Anime.Episode> episodes){String[] labels=new String[episodes.size()];for(int i=0;i<episodes.size();i++){Anime.Episode ep=episodes.get(i);labels[i]="Серия "+Ui.number(ep.number)+(ep.future?" · скачать после выхода":(ep.name.isEmpty()?"":" · "+ep.name));}return labels;}
    private static int closest(ArrayList<Anime.Episode> episodes,double suggested){int index=0;double best=Double.MAX_VALUE;for(int i=0;i<episodes.size();i++){double diff=Math.abs(episodes.get(i).number-suggested);if(diff<best){best=diff;index=i;}}return index;}
    private static boolean dead(Activity activity){return activity.isFinishing()||activity.isDestroyed();}
}
