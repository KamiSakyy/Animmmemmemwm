package app.yoru.mobile;

import android.app.*;
import android.os.*;
import android.webkit.WebView;
import java.util.concurrent.*;

public final class YoruApp extends Application {
    public static YoruApp instance;
    public final ExecutorService io=ioPool();
    public final Handler main=new Handler(Looper.getMainLooper());
    public SecureStore store;
    public ApiRepository api;
    public ImageLoader images;
    public boolean original;
    public TrafficMeter traffic;
    public MediaCache mediaCache;
    private DownloadHub downloads;
    public volatile int activePlayers;
    private static ExecutorService ioPool(){int cores=Math.max(4,Runtime.getRuntime().availableProcessors());int n=Math.max(8,Math.min(12,cores*2));return Executors.newFixedThreadPool(n,r->{Thread t=new Thread(r,"yoru-io-turbo");t.setPriority(Thread.NORM_PRIORITY);return t;});}
    public synchronized DownloadHub downloads(){if(downloads==null)downloads=new DownloadHub(this,mediaCache);return downloads;}
    public boolean savingMobile(){return store.dataSaver()&&traffic.mobile();}
    public boolean autoNextAllowed(){return store.autoNext()&&!savingMobile();}
    @Override public void onCreate(){super.onCreate();instance=this;original=AppSecurity.original(this);WebView.setWebContentsDebuggingEnabled(false);store=new SecureStore(this);traffic=new TrafficMeter(this,store);mediaCache=new MediaCache(this);api=new ApiRepository(this);images=new ImageLoader(this);channels();EpisodeUpdateReceiver.schedule(this);main.postDelayed(()->EpisodeUpdateReceiver.checkNow(this),18000);main.postDelayed(()->io.execute(()->{try{api.refreshProtection(false);}catch(Exception ignored){}}),12000);}
    private void channels(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm!=null)nm.createNotificationChannel(new NotificationChannel("yoru-updates",getString(R.string.updates_channel_name),NotificationManager.IMPORTANCE_HIGH));}}
    public static YoruApp app(){return instance;}
}
