# YORU future agent guide

Работай только в текущей ветке Arena и не переключайся на другие ветки. Пользователь ждёт готовый APK после Android-правок, а не только исходники.

## Главные правила продукта

- Отвечай пользователю по-русски и показывай этапы/проценты, когда задача долгая.
- Код Java/Kotlin/Groovy/XML должен быть чистым, без комментариев в коде и без намёков на ИИ.
- Не добавляй источники, которые требуют API-ключей.
- Не добавляй прокси для аниме-источников.
- Не возвращай AniList, SameBand, AnimeGO и SovetRomantica.
- Сохраняй быстрый режим `Все источники`; сомнительные источники не должны блокировать общий каталог.
- Kodik 2026 оставлен как рабочий источник.
- Просмотр только в нативном видеоплеере YORU. Не возвращать iframe/WebView-просмотр или выбор внешнего плеера.
- Resolver получает поток для нативного плеера; iframe не использовать.
- Для скачанного HLS/DASH не запускать пересборку/конвертацию в отдельный файл; офлайн-поток открывается во встроенном плеере YORU.
- Если внешний плеер не принимает `content://`, пользователь должен иметь действие сохранения через системный проводник Android.

## APK workflow

Основная сборка APK делается GitHub Actions workflow `.github/workflows/build-apk.yml`.

Обычный порядок:

1. Проверить `git status --short --branch`.
2. Внести Android-правки.
3. Запустить локальные smoke checks:
   - Java parse через `/tmp/javaparse/bin/python` и `javalang`, если venv уже есть.
   - XML parse через `xml.etree.ElementTree`.
   - `git diff --check`.
4. Поднять `versionName`, `versionCode`, workflow filenames, README/CHANGELOG.
5. Закоммитить исходники.
6. `git push origin arena/01a0828d-animmmemmemwm`.
7. Ждать `gh run watch <run_id> --exit-status`.
8. После success сделать `git pull --ff-only origin arena/01a0828d-animmmemmemwm`.
9. Проверить `sha256sum -c apk-output/YORU-<version>-*.sha256` и `unzip -t` для APK.
10. Открыть release APK через `present_file`.
11. В финальном ответе дать ссылки на repo commit, release APK, debug APK и Actions.

## Removed VPN notes

VPN полностью удалён в YORU 2.9.0. Не возвращать `VpnService`, Xray/libv2ray, subscription parser, нижнюю вкладку VPN и скачивание AAR в workflow без прямого нового требования пользователя.

## Актуальная база и передача — 2026-09-08

- По прямому требованию пользователя работать от `handoff/YORU-4.17.2-stable-source.zip` (versionName 4.17.2, versionCode 65), а не от отличающегося текущего `yoru-android/app` и не от 4.18.1.
- SHA-256 базы: `68b6dff27f21c5a282007302a125c8ad631d5aa20bdf0927c46002c508fa5aeb`. Оригинальный архив не перезаписывать.
- На этом этапе выполнен статический аудит без Android-правок. Отчёт: `handoff/YORU-4.17.2-AUDIT.ru.md`. Замеры на устройстве и сборка не выполнялись; Java parse не заменяет compilation.
- Всегда выдавать исходники отдельным новым ZIP с SHA-256. Не включать приватные signing-файлы, credentials, build/cache, другие архивы и лишние продукты. Для аудита выдана неизменённая копия `handoff/YORU-4.17.2-audit-baseline-source.zip`.
- Перед реализацией восстановить активную YORU-базу из указанного ZIP; не смешивать её с текущими изменёнными файлами. Другие продукты не удалять без необходимости.
- ZIP включает отсутствующий `:yuroguard`; его workflow зависит от старого ZIP с owner-signing и публикует в старую ветку. До сборки подготовить самодостаточную YORU-конфигурацию и публикацию только в текущую ветку этой сессии.
- Старый `YORU-android-2.0.1-source.zip` содержит signing.properties и keystore: не читать/публиковать значения, не копировать в новые source ZIP. План переноса подписи в CI secrets и возможной ротации согласовать отдельно; ключ самовольно не менять.
- Приоритеты оптимизации: image disk/decode вне UI, безопасное переполнение очередей вместо CallerRunsPolicy, последовательный фоновый progress writer, single-flight/cancellation, затем player и reuse карточек. Не обещать проценты ускорения без измерений.
- В 4.17.2 обнаружено расхождение с правилом iframe: PlayerActivity ждёт resolver, YummyFrame не подключён к загрузке страницы. Исправлять отдельным проверяемым изменением, сохраняя auto-mode и реальные озвучки.

## Прямые требования обновления — 2026-09-09

- НЕ МЕНЯТЬ КЭШ: не добавлять RAM-кэш, не менять текущие дисковые/медиа/SQLite/сетевые кэши, лимиты и алгоритмы. Рекомендации аудита по кэшированию НЕ согласованы и не должны выполняться.
- Разрешены безопасная обработка перегрузки executor и отмена устаревших задач, настоящий reuse ViewHolder и частичные обновления.
- Добавить постоянную очередь скачивания будущих серий с выбранными озвучкой и качеством; скачивать после фактической доступности, не по одному только расписанию. Учитывать Doze/ограничения Android, не обещать точную минуту.
- Удалить из настроек «Новые серии» и «Встроенный просмотр». Только видеоплеер YORU, без iframe.
- Для обновления выдать отдельный source ZIP + SHA-256 и готовый APK. База 4.17.2 остаётся неизменной.

## Обновление 4.19.0

- Активный код восстановлен из 4.17.2, обновлён до 4.19.0 / 69. Более поздний YoruLabs из корня не переносился.
- Новые классы: TaskQueue, ScheduledDownloads (постоянные задания, НЕ кэш), ScheduledDownloadJob, ScheduledDownloadRules.
- Календарь и серии используют reusable ViewHolder и DiffUtil; DownloadsScreen переиспользует строки.
- Не обещать скачивание в точную минуту: JobScheduler 15 минут + ограничения Android; строгий выбор заданной озвучки/разрешения. При отсутствии варианта ждать.
- Будущие задания не экспортируются как часть коллекции; это отдельная локальная очередь. Уже переданный download не отменяется удалением записи плана — управляется отдельно в загрузках.
- Existing signing workflow сохранён для совместимости установленного APK. Новые исходники не включают owner-signing. Требуется отдельное согласование безопасной миграции подписи; эта задача не меняет ключ.

### Проверенная выдача 4.19.0

- Финальный CI: https://github.com/KamiSakyy/Animmmemmemwm/actions/runs/34273631860 — success (unit tests, debug/release assembly, apksigner verify).
- Код сборки: `8988a6814ace085be1d80dacaf86a7e9dda8010d`; APK commit: `c872c27`.
- Release: `apk-output/YORU-4.19.0-release.apk`, SHA-256 `d0c15f808e3333b80ceae9d75816e5ef1af564d76d421477c9eb65ab46ec9b1a`.
- Debug: `apk-output/YORU-4.19.0-debug.apk`, SHA-256 `17f9e51793f3e2224f6bfd0c4db1b2e83b7d12db86f56154804597f31acda634`.
- Проверены binary manifest: 4.19.0 / 69, package `app.yoru.mobile` / `.debug`, ScheduledDownloadJob с BIND_JOB_SERVICE; ZIP integrity и SHA-256 обоих APK.
- Сертификат release совпадает с APK 4.17.2. Проверок на физическом устройстве не было; не выдавать unit tests за Android UI/background smoke.
- Source ZIP: `handoff/YORU-4.19.0-source.zip` + SHA-256 рядом. Последующие изменения памяти/документации после CI не меняют собранный Android-код.

## Исправления 4.19.1 — 2026-09-09

- Продолжение 4.19.0 (линия стабильной базы 4.17.2), versionCode 70. Не откатывать выполненные исправления на старый ZIP.
- Календарь: общий GraphQL + REST fallback загружаются независимо от избранного; избранное только дополняет. Не допускать, чтобы наличие личных событий выключало общий fallback. При отсутствии общей сети явно показывать неполноту данных, не обещать полный онлайн-календарь.
- При возвращении на вкладку календаря reset к «Все / Все дни». Все полученные события отображаются единым RecyclerView без искусственных первых пяти. Избранное — только ручной фильтр.
- При открытии календаря/явном обновлении выполнять сетевое обновление с показом прежних данных до результата; сами механизмы/TTL/лимиты кэша не менять и не очищать.
- Убрана большая кнопка «Будущие скачивания». Каждое ожидающее задание — обычная карточка серии с пометкой «Будущее скачивание», озвучкой, качеством и отменой. После передачи DownloadManager не дублировать обычную загрузку.
- Изучение сторонних GitHub-приложений и VK Cloud — только предложения. Ничего из исследования не внедрять без отдельного одобрения пользователя; никаких новых proxy/VPN/cloud-маршрутов в этом исправлении.

### Выдача 4.19.1 и исследования

- CI https://github.com/KamiSakyy/Animmmemmemwm/actions/runs/34276064726 — success; Android-код `b6de1c442bc3e56313cd2e46798de93539450157`, APK commit `5c0fba3`.
- Release SHA-256: `3ea95b34dbd7a3f455e9f423e2d148f2294b63e3e14bad0f90302e3c849940b4`; debug: `ac067650303be92c6451c348c13b21d31d3432019a13dc80852a6baf546c6dea`.
- Проверены APK manifest 4.19.1/70, package, SHA-256, ZIP integrity, совпадение сертификата release с 4.19.0. CI запускает unit tests; отчёт опубликован в artifact `yoru-4.19.1-tests`, его скачивание в sandbox завершилось сетевым EOF. Не утверждать локальное чтение отчёта.
- Исследование приложений: `handoff/YORU-FUTURE-IDEAS-2026-09-09.ru.md` (Aniyomi, Anikku, Animeko). Никаких реализаций без одобрения.
- VK Cloud: `handoff/YORU-VK-CLOUD-ASSESSMENT-2026-09-09.ru.md`. Собственный gateway/CDN не гарантирует доступность при белых списках; при отсутствии радиосвязи облако не поможет. Предложен только тест на собственном контенте после одобрения. Облако/proxy/VPN не добавлялись.
- На физическом устройстве календарь и карточки не проверялись. Доступность внешнего API из региона пользователя не подтверждена.

## Подтверждение стабильной базы пользователем

- Пользователь подтвердил: 4.19.1 — самая стабильная версия, всё работает. Считать её новой подтверждённой базой дальнейших изменений; сохранить APK и `handoff/YORU-4.19.1-source.zip` неизменными.
- Предложения из `YORU-FUTURE-IDEAS-2026-09-09.ru.md` пользователю не понравились: они НЕ одобрены, не реализовывать и не предлагать повторно без нового основания.
- Пользователь интересуется переносом дизайна animetka.com. Это пока вопрос о возможности, не разрешение менять интерфейс. Сначала согласовать объём и визуальный прототип. Нативный плеер, рабочие сценарии и текущий кэш сохранять.

### Исследование Animetka — отдельная выдача

- По запросу пользователя получен настоящий публичный frontend-снимок animetka.com, а не сторонний одноимённый GitHub-проект. CI `34278305316` — success, получение через Chromium/Playwright без входа и обхода защиты.
- `handoff/ANIMETKA-public-frontend-2026-09-09.zip` + SHA-256: 17 оригинальных ресурсов (HTML, основной JS/CSS, PlayerJS, service worker, SVG и 7 постеров), 4 скриншота, DOM/текст/computed styles, manifest, сборщик и наш функциональный отчёт/индекс. Это НЕ полный исходный репозиторий/сервер, source maps не получены, не автономный клон.
- Отчёт отдельно: `handoff/ANIMETKA-FUNCTIONAL-REVIEW-2026-09-09.ru.md`. Проверены главная, открытие фильтров и боковой карточки, мобильная ширина. Плеер, авторизация, папки, профили, друзья, чат/звонки, активность и темы описаны по коду, не выданы за проверенную серверную работу. Мессенджер помечен сайтом как демо; синхронный совместный просмотр не подтверждён.
- Исходные public-ресурсы в ZIP побайтово сохранены. README уточнён по фактическому составу: PlayerJS есть, отдельных шрифтов/manifest PWA нет, оригинальный HTML содержит внешние ссылки на аналитику.
- YORU 4.19.1, APK/source ZIP и Android-код не менялись. Пользователь сначала изучит дизайн сам; внедрение по-прежнему НЕ согласовано.

### Мобильная тёмная Animetka против стабильной YORU — 2026-09-09

- Новый запрос пользователя: изучить именно мобильную тёмную версию и подробно сравнить с YORU, предложить недостающее. Это исследование, НЕ согласие внедрять.
- Финальный мобильный capture CI `34280698406` — success, bot `a1d3017`. 21 снимок/состояние; Chromium Android UA, touch, DPR1, 390×844 и главная 360/430 px. Тема включена реальной кнопкой меню, dark сохраняется после reload. Физический телефон, клавиатура Android, TalkBack и скорость не тестировались.
- Проверены меню/палитра, фильтры/чекбоксы жанров, top/random, краткая карточка, страница тайтла и раскрытие плеера, поиск Наруто и подсказки, пустая гостевая история, меню входа. Не применялись сочетания фильтров; вход/аккаунты/социальные функции не тестировались. Медиа/аналитика блокировались; видео НЕ проверено.
- Доказательства: `handoff/ANIMETKA-mobile-dark-2026-09-09.zip` + SHA, `ANIMETKA-mobile-dark-summary.json`. ZIP содержит оригинальные JS/CSS, PNG/HTML/TXT/metrics JSON, EVIDENCE и наш сравнительный Markdown.
- Основной отчёт: `handoff/YORU-vs-ANIMETKA-MOBILE-DARK-2026-09-09.html` — автономная тёмная HTML-страница с 8 настоящими скриншотами; Markdown рядом. Генератор `tools/build-animetka-mobile-report.py` берёт Markdown/ZIP и обновляет HTML, вложенный отчёт и SHA.
- Все 44 Java-файла сверены побайтово со стабильным source ZIP 4.19.1; Android/APK/source ZIP не менялись.
- Реальные различия: несколько жанров/типов, годы от–до, минимальный рейтинг, студия, выбор цветов; эндинг по таймкодам, социальный слой и временная статистика — отдельные неподтверждённые/низкоприоритетные сценарии, не согласованный план. Папки, история, продолжение, любимые озвучки, рейтинг карточки, связанные тайтлы, скриншоты и опенинг в YORU УЖЕ есть.
- Статистика YORU: краткая сводка доступна; FeaturePanels.stats и profileAction(insights) есть, но ProfileScreen.appBlock не выводит insights. SecureStore.stats суммирует последние номера серий/позиции, это не точный журнал времени просмотра. Ui.Card выводит глобальное favoriteVoiceSummary, не подтверждённую доступность дорожки каждого тайтла.
- Предложения только для обсуждения: действия карточки поднять до длинного описания, расширить фильтры после проверки источников, разгрузить карточки, опциональная нейтральная тёмная палитра, динамический главный баннер вместо заданной Фрирен. Нижнюю навигацию, собственный плеер, календарь и будущие скачивания сохранить. Кэш не трогать; при необходимости менять его ради фильтров — остановиться и согласовать, не обходить запрет.
- Нельзя копировать дефекты сайта: палитра 417.6 px при viewport390, панель карточки 75% ширины и тесный длинный заголовок, мелкие цели/часть без accessible name. У фильтров aria-label «Открыть фильтры» есть. Самостоятельная страница тайтла сайта тоже прячет раскрытие плеера ниже описания.
- CI `34280345452` получил снимки, но упал на сохранении: tracked ZIP изменялся до git pull --rebase. Workflow исправлен: сначала commit новых снимков, затем pull --rebase/push. Логи по-прежнему не скачиваются из sandbox (results-receiver EOF). Не путать это со сбоем сайта.

### Отдельное приложение YORU VK — 2026-09-09

- Пользователь отложил Аниметку до завтра и прямо попросил отдельный APK: Shikimori-карточки и стиль YORU → сезон/серия → поиск видео VK; авторизация пользовательским access token, включая полную ссылку токена Kate Mobile.
- Создан самостоятельный проект `yoru-vk-android/`, package `app.yoru.vk.prototype`, label YORU VK, 0.1.0/code1. Основную YORU НЕ менять. Её стабильные source/APK/Java неизменны; данные двух приложений изолированы.
- Отдельный workflow `.github/workflows/build-yoru-vk.yml`; финальный CI `34282425126` success, source commit `3376936aeb46644e4c1845dcddebb469beaa5a76`, bot `e11c801`. Первая сборка `34282226171` также запускалась; промежуточная pending `34282378177` отменена concurrency в пользу финальной.
- APK `apk-output/YORU-VK-0.1.0-prototype.apk`, 3,858,081 bytes, SHA256 `ba4f3d626302520fbfa5564afd75da7768beca97964ff034ed884d2ddaa58b44`. Подпись отдельная ТЕСТОВАЯ Android Debug, SHA256 сертификата `e8a07c8c2bcc4df4c39b134592b5402b69f0d1c51005d83652ffbaa716245238`. Release-вариант не debuggable; будущий runner может дать другую подпись → понадобится переустановка YORU VK. Для стабильных обновлений отдельно организовать постоянный ключ, старую подпись YORU не трогать/не копировать.
- `handoff/YORU-VK-0.1.0-build.json`: 26 unit tests, 0 failures/errors/skipped; Shikimori GraphQL публичный probe ID11757 Sword Art Online success. Локально проверены APK SHA/ZIP/binary manifest. Физического устройства и авторизованного VK end-to-end НЕ было.
- Реализация: Shiki GraphQL + REST fallback, карточки/поиск/related; редактируемые сезон/серия/озвучка, RU/original запрос; VK users.get/video.search/video.get API5.199, filters=vk/adult=0, 30/страница/до500, переключатель >10min; переиспользуемые GridView/ListView holders; Media3 MP4/HLS/DASH только из разрешённых files. Нет iframe/обхода, соцфункций и переноса источников YORU.
- Важное ограничение: официальный video.search требует user token с video, выдаваемым приложениям ограниченно; files зависит от прямой авторизации. Приём токена Kate Mobile НЕ гарантирует права/прямые видео. UI честно показывает ошибки 5/6/7/14/15/17 и отсутствие files. Правильность серии по названию загрузки не гарантируется. Токен пользователя никогда не просить в чат.
- TokenParser понимает raw/query/fragment/encoded VK URL; не переходит по ссылке. AES-GCM/Android Keystore, allowBackup=false/data extraction excludes, FLAG_SECURE, no autofill/saved field; токен только HTTPS POST api.vk.com, redirects запрещены; нет токена в media headers, логах и исходниках. Delete token удаляет локальный ключ/шифротекст; серверный отзыв делается в самом VK.
- Исследованы официальный dev.vk.com/en/method/video.search (прямое открытие бывает техработы), VKCOM/vk-api-schema commit `333481bd082ad747d4873ef4a77f9247097eeef0`, Shikimori API docs. katemobile.ru HTTP500; частный Kate API/секрет не получен и не использован. Старые форумные обходы не выдавать за рабочие методы 2026.
- Документы: `handoff/YORU-VK-0.1.0-BUILD.ru.md`, `yoru-vk-android/README.ru.md`. Отдельный source ZIP + SHA создаёт `tools/package-yoru-vk.py`, без ключей/токенов/APK и без всего YORU. После исправления только README итоговых permissions использовать [skip ci], чтобы не пересобирать неизменённый Android-код и не менять тестовую подпись.
- Итоговый manifest включает INTERNET, ACCESS_NETWORK_STATE и signature DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION от AndroidX. Не повторять раннюю неточную фразу «в APK только INTERNET».

## YORU VK Web 0.2.0 — активная база отдельного эксперимента (09.09.2026)

- Пользователь отверг Kate/access-token подход 0.1.0 после новостей апреля 2026; разрешил веб только в отдельном приложении и попросил сразу несколько способов. Токенный прототип 0.1.0 — исторический deliverable, не активное решение.
- `yoru-vk-android/` теперь 0.2.0/code2, label YORU VK Web, **новый ID app.yoru.vk.web**. Сосуществует с YORU 4.19.1 и app.yoru.vk.prototype; не читает/не удаляет их данные. Старую тестовую подпись для обновления не требует. Основной проект `yoru-android/`, его кэш, APK/sourceZIP 4.19.1 неизменны относительно b18a2b0.
- Удалены TokenParser/TokenVault/PlaybackActivity, native users.get/video.search/video.get и Media3. Сохранён Shikimori-каталог/карточки/поиск сезона/серии/озвучки, WebRoutes/WebActivity реализуют официальный веб без ручного токена.
- Четыре маршрута: VK Видео ПК (по умолчанию desktop WebView), прямой мобильный VK Видео UTF-8, Яндекс/Google site:VK. Плюс прямые video/z/video_ext ссылки и внешний браузер/app chooser. Мобильный и ПК — один backend, не два независимых источника.
- Probe34283637592: legacy редирект vk.com/vkvideo.ru в m.vkvideo.ru перевёл кириллицу в CP1251-проценты, выдача нерелевантна. Не считать HTTP200 доказательством поиска. Probe34284081252: прямой mobile UTF8 сохранил правильный запрос, появились подсказки, результаты оставались загрузкой; desktop через видимое поле поиска дал релевантные SAO-карточки без входа. Яндекс/Google на CI-IP показали CAPTCHA, не обходилась. JSON/PNGZIP в handoff/YORU-VK-web-{probe,verified}-2026-09-09.*. `tools/probe-vk-web.py` теперь воспроизводит уточняющий probe.
- Никаких проверок авторизованного VK-входа/воспроизведения или физического Android: не заявлять полный E2E. Штатная сессия сайта может быть обязательной; нет обхода защиты, подбора hash/секретов, извлечения потоков. Video_ext без разрешения/необходимого hash может не работать.
- WebView: HTTPS/allowlist верхних доменов, видимый host, no JavaScript bridge/getCookie/media interception, strict TLS, file/content/mixed-content/third-party-cookies/debugging off, permissions denied. Обычные cookies+DOM storage только нового пакета; меню удаления веб-сессии не трогает YORU/браузер. Фон уничтожает WebView (позиция видео может потеряться), поворот web Activity без пересоздания.
- CI **34284333596 success**, исходный commit **4110655440e7f57bcd2e3462477dfc62da14828e**, APKbot **d2a4c84**. **36/36 JUnit**, live Shiki11757 success; manifest/подпись и DEX проверены, токенные классы отсутствуют. Permission только INTERNET, nondebuggable, min26/target36.
- APK `apk-output/YORU-VK-0.2.0-prototype.apk`: **42,512bytes**, SHA256 **e6ad20ed4a4331a8957408006791c2ad903abc16c9cdbabe436dbdfdadb7c0fc**. Малый размер штатный: движок системного WebView, без Media3.
- Source `handoff/YORU-VK-0.2.0-source.zip`: **32 files,101,574bytes**, SHA256 **6fecb958cc3a53f88a5fc5dae0e092a60440f2cc19d3d2a5329a347824b087a7**. Согласован с файлами, без APK/ключей/build. Документация: README.ru.md, handoff/YORU-VK-0.2.0-BUILD.ru.md, build.json. Packager теперь выпускает 0.2.0.
- Подпись всё ещё временная CI Android Debug, cert SHA256 **c057db87bf85a514ca5d06e65e3bb8483d0696e9b942a3ff81e64cb8e7d04c24**. Будущая тестовая сборка того же пакета может требовать переустановки только YORU VK Web. Не использовать/публиковать ключ основной YORU.
- Исследование/перенос дизайна Animetka остаются отложенными, перенос не согласован. Ограничения/отвергнутые идеи основной YORU сохраняются.

## Production-запрос от 2026-09-14 — новая активная задача

- Основная база снова YORU 4.19.1: `handoff/YORU-4.19.1-source.zip`, SHA256 `6b76e9c171c747f72225c95324c8bd650e328b6e211379f31542d73032445f61`. Все файлы yoru-android сверены с ней перед началом: совпадают. Эксперимент YORU VK не является базой.
- ОБЯЗАТЕЛЬНО до обновления изучить `org.xjiop.vkvideoapp-568.apk` (SHA256 `f00edf653092c4e291c9325d3594692bb83f8232e670100fefe8ab5486898606`) через JADX + Apktool, включая все DEX/ресурсы/smali; проверить HLS, перехват, поиск и загрузки. Декомпиляция не гарантирует оригинальных имён/исходников до обфускации. Не копировать чужие секреты, не обходить DRM/права доступа.
- Новый root `ANIMETKA-mobile-dark-2026-09-09.zip` побайтно совпадает с уже исследованным handoff-архивом (SHA256 `1d329a7f848fca00ffd16a888e828a0c843f8d2e911de4d9debc5cdaf7b8d172`). Внутри 90 файлов: снимки HTML/PNG/JSON/TXT плюс собранные JS/CSS, не исходный сервер/React-проект. Теперь пользователь РАЗРЕШИЛ заимствовать функциональные идеи и улучшать существующий дизайн, но СТРОГО НЕ МЕНЯТЬ цвета и не заменять дизайн целиком.
- ЧИСТЫЙ КОД: без комментариев в Java/Kotlin/Groovy/XML/JS и без runtime-логов, printStackTrace, HTTP logging interceptors и отладочных дампов. Пояснения/ограничения/результаты — в Markdown, не в коде. Это не запрет проверять сборку или сохранять отчёт тестов.
- Собственный нативный плеер основной YORU обязателен. Кэш не менять, RAM-кэш не добавлять. Мерцание исправлять привязкой/reuse/отображением и очередью декодирования, не новым хранилищем.
- Приняты все 36 пунктов последнего сообщения: Shiki-рейтинг вместо озвучки в карточке со старой звездой; топовая бесконечная лента порциями 6 и плавное обновление/календарь; популярность озвучек только при реальных данных; плеер ниже описания с сезонами/сериями; связность сезонов; ежедневные «Рекомендации»; полный жанровый каталог без скрытого исключения жанров; быстрые обложки и рекомендации; миграция сети на подтверждённый свежий OkHttp и приоритет видимого экрана; убрать Quality+; плавный поиск/история с обложками; автообновление раз в час/жестом без текста о сохранённой подборке; кнопки коллекций; исправление обновления расписания; HLS/native player; 144/240 только когда доступны; честный точный размер при известности; SAF-папка; иконки удаления/настроек; обои с обрезкой и предпросмотром вкладок/прозрачностью; МСК/локальное время; кликабельные жанры; жесты/замок/скриншот плеера; полные изображения по умолчанию и экономия трафика опционально; согласование количества серий; убрать поясняющий текст поиска, верхнюю «Историю», прогресс карточки; крестик фильтров; SDK37 после проверки официальной доступности/совместимости.
- Не выдумывать просмотры/популярность озвучек от Shikimori: проверить схему. Точный полный размер произвольного HLS/live до загрузки не гарантируется; неизвестность не подменять оценкой. «Моментально» и production-ready не обещать без оснований.
- Пока идёт обязательный разбор, код/версию основной YORU не менять. После него вести статус каждого пункта и выдавать новый APK + отдельный source ZIP, не перезаписывая 4.19.1.

### Результат обязательного разбора — 2026-09-14

- CI `34813839601` НЕ ЗАПУСТИЛ runner: GitHub annotation сообщает failed account payments / spending limit. Это Billing, не ошибка исходников/декомпилятора и не auth-проблема. Не просить пароль/PAT и не менять GitHub billing за пользователя. Нового APK нет.
- Локально через PyPI получены Androguard DAD и Java runtime. Все 3 DEX разобраны: 20 622 класса, 99 545 методов; DAD выдал 20 622 class representations, ошибок экспорта классов 0. Для всех классов сохранены инструкции Dalvik; 1 189 XML успешно декодированы. JADX/Apktool НЕ выполнялись: не выдавать результаты DAD за JADX. Это не исходники автора и не компилируемый Java/smali; native C/C++ не восстановлен (в APK лишь datastore_shared_counter.so для 4 ABI).
- Локальный полный незамаскированный анализ лежит в игнорируемом/исключённом из snapshot `workspace-output/vk568-local/build/`; для продолжения устойчиво сохранён текстовый review ZIP (opaque/credential-like literals замаскированы). Не запускать извлечённый APK/код и не использовать/расшифровывать чужие client credentials для YORU.
- ZIP `handoff/VKVIDEO-568-local-decompiled-review.zip`: 39 051 399 bytes, 42 430 entries, SHA256 `4e16d24608857a8d46a99697fa774a73e16345beb1c808c5fca3c9388566b1f4`. 758 literals замаскированы, это не число доказанных секретов. Evidence: `VKVIDEO-568-analysis-evidence.json`. Извлекать в `workspace-output/.../build`, иначе 42k файлов превысят лимит snapshot.
- Ключевые факты: ea4.h → video.search с VK SDK auth; VKApiVideo.files → hls_fmp4/hls/hls_ondemand/hls_live и mp4_144..2160; PlayerDataModel.setMP4QualityList добавляет только существующие варианты. Не выдавать чужой SDK за поиск без сессии и не переносить чужие OAuth identifiers.
- DownloadsService/ar0/xq0/vq0: файловая очередь, HEAD, Range/206, FileDescriptor/SAF, ftruncate/pwrite, состояние частей/pause/resume. @string/download_about_info ПРЯМО говорит: HLS скачивается только сторонними приложениями! Не обещать готовый native HLS downloader из этого APK. g7 пишет список готовых ссылок в M3U, не скачивает HLS-сегменты.
- Все найденные shouldInterceptRequest/onLoadResource проверены по контексту: ez5/rz5 AdWebView/mraid, lm5 wrapper, ls5 consent, yads/ea3 реклама. Это не универсальный HLS перехватчик. TLS yd4 содержит условный proceed после собственных проверок; в YORU подобное не копировать. Рекламу/аналитику/лишние permissions и внешние плееры не переносить.
- Animetka: PlayerInline, InfiniteSearchCheckboxList, справочники /api/anime/genres/translations, favorite_voices, top по shikimori_rating. В архиве собранный Vue JS, не исходники сервера. Не копировать некорректную связку Re:Zero TV4 с описанием/годом первого сезона и счётчик 25/19.
- Официальный Shikimori AnimeType (commit a900114c48be8fdbc212139017b18e81a1c9a76f): fandubbers/fansubbers — строки, просмотров по озвучкам в просмотренной схеме нет. Популярность/просмотры не выдумывать. Есть chronology и ISO next_episode_at.
- OkHttp официальный changelog 5.5.0 от16.08.2026; square/okhttp перенаправляет на lysine-dev/okhttp, подтверждено GitHub API (main1402451779106b1e6d3e78f629e1dbfb79317f21). SDK37 подтверждён официальными Android17 docs. Это НЕ означает успешную Maven/SDK установку или Android сборку; CI блокирован.
- Отчёт `handoff/YORU-PREUPDATE-APK-ANIMETKA-REVIEW-2026-09-14.ru.md`; полный реестр 36 пунктов `handoff/YORU-PRODUCTION-36-STATUS-2026-09-14.ru.md`. Все функции пока PLANNED, не IMPLEMENTED. Основные 106 файлов yoru-android повторно сверены с sourceZIP4.19.1: совпадают, код основной YORU не менялся. Следующая задача — реальная реализация после восстановления рабочего сборочного окружения, а не повторное обсуждение разрешённых пользователем функций.
- Незавершённые `tools/smoke-vk-android.py`, `handoff/YORU-VK-0.2.1-BUILD.ru.md`, `...playback-regression.json` пришли из прошлого прерванного VK-этапа. Не относить их к production-изменениям, не очищать без необходимости. Старый подтверждённый просмотр VK-ссылок остаётся нетронутым.

### Первый implementation checkpoint — 4.20.0-dev.1

- Начата реальная реализация после завершённого разбора: HomeScreen (RecyclerView, Shiki по6, дневная рекомендация, hourly/pull), ScheduleClock (МСК/системная зона/DST), OkHttp transport adapter и Media3 upstream, отмена активного Call из TaskQueue, динамические Shiki-жанры, кликабельные жанры, исправления подписей/карточек/фильтров.
- Версия 4.20.0-dev.1/code71 — НЕ завершённый production-релиз. compile/target37 и build-tools37 настроены, но AGP8.13.2/Gradle8.13/SDK37 и OkHttp5.5.0 необходимо подтвердить сборкой. Не скрывать предупреждения suppressUnsupportedCompileSdk.
- Удалён только presentation прогресса карточки, сохранение позиции осталось. ★ и RGB-палитра сохранены. MediaCache offline/temporary/onlineFactory/offlineFactory сверены: без изменений. YoruCache не изменён. ImageLoader изменён только в сетевом вызове; кэш/декодирование/порядок URL не оптимизированы. Никакого нового RAM-кэша.
- Network.java — единый OkHttp с прежними caller timeout/headers, без HTTP cache/interceptor logs; media без общего callTimeout. HttpURLConnection adapter обеспечивает case-insensitive headers и закрытие call по TaskQueue flag. Автоматические и ручные cross-origin redirects не переносят Cookie/Authorization/Proxy-Authorization. WebView и дочерние plain Executor ещё не полностью покрыты scope cancellation: не заявлять «все запросы/вся отмена завершены».
- Написаны NetworkTest, ScheduleClockTest, QualityLabelTest (11 новых тестов). Они пока НЕ выполнены; javalang проверил синтаксис 50 Java-файлов, это не javac/Android сборка. Нет SDK/javac локально. Нужна успешная CI-сборка прежде, чем выдавать APK.
- Полный фактический статус CODE/PARTIAL/PLANNED/BLOCKED DATA внесён в handoff/YORU-PRODUCTION-36-STATUS-2026-09-14.ru.md. Inline player/сезоны, SAF, обои, жесты/lock/screenshot и полная metadata reconciliation ещё впереди. Не объявлять все36 готовыми.
- Source ZIP checkpoint должен исключать owner-signing, ключи, APK, build/.gradle и baseline APK; стабильную 4.19.1 не перезаписывать. Старые незавершённые VK-файлы остаются вне этого checkpoint.

### Проверенный итог checkpoint — CI 34816820164

- HEAD реализации `458611f032c05e2bc4a2b275d6e274880f8c104e`. GitHub Billing больше НЕ текущий блокер: runner выполняет задачи. Ручной workflow_dispatch вернул403 Resource not accessible by integration, но автоматический push CI работает; не требовать Billing fix для уже работающего runner.
- Новый точный блокер SDK37: `sdkmanager` пишет `Warning: Failed to find package 'platforms;android-37'`, включая `--channel=3`. SDK37 release APK не получен. Android AAR `com.squareup.okhttp3:okhttp-android:5.5.0` реально разрешился Maven и требует compile37: это подтверждено checkDebugAarMetadata, не предположение.
- Обновлены AGP9.2.1/Gradle9.4.1, SHA Gradle `2ab2958f2a1e51120c326cad6f385153bb11ee93b3c216c5fccebfdfbb7ec6cb`. Официальная матрица https://developer.android.com/build/releases/agp-9-2-0-release-notes подтверждает max API37, Gradle9.4.1, build-tools36.0.0, JDK17. Не заменять numeric SDK37 фальшивым android.jar/переименованным SDK36.
- Для компиляции/JUnit добавлен ЯВНЫЙ `-PverifyOnSdk36`: compile/target36, versionName `4.20.0-dev.1-verification-sdk36`, dependency okhttp-jvm5.5.0 вместо Android AAR. CI запускает только testDebugUnitTest+assembleDebug, не публикует APK; явные release tasks запрещены guard. Это НЕ замена конечному SDK37/Android OkHttp и не его runtime-тест.
- CI `34816820164` / job `103889120676` SUCCESS для Java+JUnit+assembleDebug в таком проверочном режиме. SDK37 job `103889120912` FAILED до Gradle из-за отсутствия SDK. В исходниках29 @Test (11 новых); XML-отчёты находятся в CI artifact, скачать через gh здесь не удалось (EOF Azure blob). Не выдавать статический подсчёт за локально разобранные XML. Evidence job statuses: handoff/YORU-4.20.0-dev.1-ci-jobs.json.
- Компилятор обнаружил конфликт нового имени Network с android.net.Network. Исправлено переименованием нового transport в **HttpTransport.java**; соответствующий повторный CI прошёл. Не восстанавливать старое имя класса. Тестовый файл NetworkTest.java проверяет HttpTransport.
- Дополнительно: мини-обложки подсказок, история с точным локальным совпадением/честной search icon иначе, LayoutTransition, удалена верхняя «История» именно каталога тоже. Новая geometry корзины и48dp в DownloadsScreen. Поля фильтров сохраняются в Bundle; settings action не запускает жанровый lookup.
- ImageLoader теперь также сначала пробует highQuality URL для НОВЫХ загрузок без dataSaver и ограничивает размер decoded bitmap через inSampleSize/heap budget. Это не перекодирование raw bytes и не изменение файлов/ключей/лимитов/TTL/очистки кэша; существующие low-cache файлы не перезаписывать насильно. Same-key binding/sync disk decode ещё требуют работы, полного исправления мерцания не заявлять.
- Неизвестный Anime.status (включая from JSON без status/ongoing) не превращается в released по умолчанию. Resolver не интерпретирует произвольное число1234 как разрешение; Sibnet без metadata — неизвестное качество. Полная reconciliation сезонов/total ещё не готова.
- Все36 ещё НЕ завершены. Следующие крупные блоки: общий собственный inline player/сезоны; SAF+размеры; lock/PixelCopy/жесты; редактор обоев; reconciliation расписания/эпизодов; все провайдерские жанры и полная история. Продолжать в этой ветке, не возвращаться к повторной декомпиляции и не делать live Shiki emulator checks, которые пользователь запретил.

### Текущий checkpoint — 4.20.0-dev.2/code72

- Предыдущие записи выше исторические. Текущая основная конфигурация — SDK37/Android OkHttp5.5, AGP9.2.1/Gradle9.4.1. `-PverifyOnSdk36` теперь отдельная Android5.4 совместимая debug-сборка, package.debug и явная версия compat-sdk36-okhttp5.4. `-PverifyJvmTransport` дополнительно выбирает JVM5.5 только для unit/compile проверки. Release tasks с SDK36 запрещены; JVM APK не публиковать.
- Ни совместимый APK, ни успешные JVM тесты не закрывают требование SDK37 и Android17 runtime. CI сохраняет отдельный compatibility APK, SHA и реальные JUnit counts из XML. Не выдавать ожидаемое число47 за выполненные тесты без отчёта.
- EpisodeRules, provenance Shiki рейтинга/total, known-ID guards, отмена дочерних HTTP pools, отсутствие синтетических календарных дат реализованы. Полный статус36 обновлён в реестре.
- ImageLoader: только presentation/scheduling cached decode, прежний fast-hit early return без изменения mtime/trim; политика кэша не тронута. Search metadata — пользовательская история с существующим лимитом14, не RAM-кэш.
- SAF progressive copy теперь WorkManager + private SharedPreferences operational journal, не кэш и не импортируемые настройки. Job retry использует тот же operation ID, частичный созданный документ очищается. Нельзя обещать отсутствие сироты в микропромежутке createDocument→commit; сбои/отзыв permission/cloud providers требуют Android-проверок. HLS не конвертировать.
- PixelCopy ограничен одной активной операцией (live operation flag, не кэш). Inline lock запрещает frame/fullscreen; raw streams используются без лишнего resolver при отсутствии voice preference. Полноэкранный handoff выбора озвучки/качества ещё не завершён.
- Код по-прежнему без комментариев и без собственных логов. Палитра, звезда, кеши и отдельный VK playback не менять. Не запускать live Shiki/emulator probes вместо выдачи артефактов.

- Проверенный dev.2 итог: CI34821079006 / source c7aa6b2f3e1e7e9d08ca659c6e0efb23644533af. Compatibility job103902560825 SUCCESS, Android APK сохранён ботом2c25519. Разобранные XML дают47 тестов/0 failures/0 errors/0 skipped на каждом из двух dependency profiles. SDK37 job103902561192 FAILURE. Это фактические результаты, не статический подсчёт.
