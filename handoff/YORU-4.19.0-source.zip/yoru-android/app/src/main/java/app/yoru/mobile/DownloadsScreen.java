package app.yoru.mobile;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.media3.exoplayer.offline.*;
import org.json.*;
import java.util.*;

public final class DownloadsScreen extends LinearLayout {
    private final Activity activity;private final DownloadHub hub;private final ArrayList<Download> rows=new ArrayList<>();private final TextView summary,empty;private final ListView list;private final Adapter adapter;private final Handler handler=new Handler(Looper.getMainLooper());private String lastSignature="";
    private final Runnable update=new Runnable(){public void run(){refreshSafe();handler.postDelayed(this,5000);}};
    public DownloadsScreen(Activity a){super(a);activity=a;hub=YoruApp.app().downloads();setOrientation(VERTICAL);setPadding(Ui.dp(a,17),Ui.dp(a,15),Ui.dp(a,17),Ui.dp(a,8));addView(Ui.label(a,"ОФЛАЙН-БИБЛИОТЕКА"));Ui.space(this,10);addView(Ui.text(a,"Загрузки",28,Ui.TEXT,true));Ui.space(this,9);addView(Ui.text(a,"Скачанные серии с превью, качеством и быстрым запуском во встроенном плеере YORU.",12,Ui.MUTED,false));Ui.space(this,12);addView(Ui.button(a,"Будущие скачивания",false,()->ScheduledDownloads.showQueue(a)));Ui.space(this,16);summary=Ui.text(a,"",12,Ui.PURPLE,true);addView(summary);Ui.space(this,12);list=new ListView(a);list.setDivider(null);list.setClipToPadding(false);list.setVerticalScrollBarEnabled(false);list.setPadding(0,0,0,Ui.dp(a,15));list.setBackgroundColor(Ui.BG);adapter=new Adapter();list.setAdapter(adapter);empty=Ui.text(a,"Здесь появятся скачанные серии.\n\nОткройте аниме и нажмите «Скачать» рядом с нужной серией. Готовые загрузки открываются прямо в YORU.",14,Ui.MUTED,false);empty.setPadding(Ui.dp(a,20),Ui.dp(a,40),Ui.dp(a,20),Ui.dp(a,20));empty.setGravity(Gravity.CENTER);FrameLayout frame=new FrameLayout(a);frame.addView(list,new FrameLayout.LayoutParams(-1,-1));frame.addView(empty,new FrameLayout.LayoutParams(-1,-1));addView(frame,new LinearLayout.LayoutParams(-1,0,1));list.setOnItemClickListener((parent,v,pos,id)->{try{if(pos>=0&&pos<rows.size()){Download d=rows.get(pos);if(d!=null&&d.state==Download.STATE_COMPLETED){JSONObject m=DownloadHub.metadata(d);Ui.openOffline(activity,d.request.id,Anime.from(m.optJSONObject("anime")),m.optDouble("episode",1));}}}catch(Throwable ignored){}});}
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();handler.post(update);}
    @Override protected void onDetachedFromWindow(){handler.removeCallbacksAndMessages(null);super.onDetachedFromWindow();}
    private void refreshSafe(){try{refresh();}catch(Throwable e){summary.setText("Загрузки восстановлены после битой записи. Если повторится — удалите старую загрузку.");empty.setVisibility(rows.isEmpty()?VISIBLE:GONE);try{adapter.notifyDataSetChanged();}catch(Throwable ignored){}}}
    private void refresh(){ArrayList<Download> fresh=new ArrayList<>(hub.all());int complete=0,active=0;StringBuilder sig=new StringBuilder();for(Download d:new ArrayList<>(fresh)){if(d==null||d.request==null)continue;if(d.state==Download.STATE_COMPLETED)complete++;if(d.state==Download.STATE_DOWNLOADING)active++;int pct=d.getPercentDownloaded()<0?-1:(int)d.getPercentDownloaded();sig.append(d.request.id).append(':').append(d.state).append(':').append(pct/8).append('|');}summary.setText("Готово: "+complete+" · скачивается: "+active+" · "+Ui.bytes(YoruApp.app().mediaCache.offlineBytes()));empty.setVisibility(fresh.isEmpty()?VISIBLE:GONE);String next=sig.toString();if(!next.equals(lastSignature)){lastSignature=next;rows.clear();rows.addAll(fresh);adapter.notifyDataSetChanged();}}
    private void actions(Download d){if(d==null||d.request==null){Ui.toast(activity,"Эта запись загрузки повреждена");return;}JSONObject meta=DownloadHub.metadata(d);Anime a=Anime.from(meta.optJSONObject("anime"));String voice=meta.optString("voice","");String title=(a.title==null||a.title.isEmpty()?"Загрузка":a.title)+" · серия "+Ui.number(meta.optDouble("episode",1))+(voice.isEmpty()?"":" · "+voice);ArrayList<String> choices=new ArrayList<>();if(d.state==Download.STATE_COMPLETED){choices.add("Смотреть в YORU");if(OfflineExporter.canExport(d)){choices.add("Сохранить через проводник");choices.add("Сохранить в Видео / YORU");choices.add("Поделиться файлом");}choices.add("Информация");}else if(d.state==Download.STATE_STOPPED)choices.add("Продолжить");else if(d.state==Download.STATE_FAILED)choices.add("Обновить и повторить");else if(d.state!=Download.STATE_REMOVING)choices.add("Пауза");choices.add("Удалить загрузку");Ui.choices(activity,title,choices.toArray(new String[0]),which->handle(d,a,meta,choices.get(which)));}
    private void handle(Download d,Anime a,JSONObject meta,String choice){try{if(choice.equals("Смотреть в YORU"))Ui.openOffline(activity,d.request.id,a,meta.optDouble("episode",1));else if(choice.equals("Сохранить через проводник"))OfflineExporter.saveWithPicker(activity,d);else if(choice.equals("Сохранить в Видео / YORU"))OfflineExporter.saveToMovies(activity,d);else if(choice.equals("Поделиться файлом"))OfflineExporter.share(activity,d);else if(choice.equals("Информация"))Ui.message(activity,"Информация",OfflineExporter.details(d));else if(choice.equals("Продолжить"))hub.resume(d.request.id);else if(choice.equals("Пауза"))hub.pause(d.request.id);else if(choice.equals("Обновить и повторить"))hub.retry(d.request.id);else confirmDelete(d);}catch(Throwable e){Ui.toast(activity,"Действие загрузки не выполнено");}}
    private void confirmDelete(Download d){Ui.confirm(activity,"Удалить загрузку?","Удалить скачанные файлы этой серии?", "Удалить",()->{hub.remove(d.request.id);refreshSafe();},"Отмена");}
    private final class Adapter extends BaseAdapter {
        public int getCount(){return rows.size();}
        public Object getItem(int position){return rows.get(position);}
        public long getItemId(int position){return position;}
        public View getView(int position,View old,ViewGroup parent) {
            DownloadRow holder;
            if(old!=null&&old.getTag() instanceof DownloadRow)holder=(DownloadRow)old.getTag();
            else holder=new DownloadRow();
            holder.bind(rows.get(position));return holder.outer;
        }
    }

    private final class DownloadRow {
        final LinearLayout outer,card;
        final ImageView poster;
        final FrameLayout preview;
        final TextView placeholder,caption,title,description,type,state,size,primary,save;
        final ProgressBar progress;
        Download download;
        Anime anime;
        JSONObject metadata;
        String imageKey="";
        DownloadRow() {
            outer=Ui.column(activity);outer.setTag(this);outer.setPadding(0,0,0,Ui.dp(activity,10));
            card=Ui.column(activity);card.setPadding(Ui.dp(activity,12),Ui.dp(activity,12),Ui.dp(activity,12),Ui.dp(activity,12));
            card.setBackground(Ui.stroke(Ui.CARD,16,activity));outer.addView(card,Ui.lp(activity,-1,-2));
            preview=new FrameLayout(activity);preview.setBackground(Ui.gradient(0xff2a2135,0xff18131f,18,activity));preview.setClipToOutline(true);
            poster=new ImageView(activity);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);preview.addView(poster,new FrameLayout.LayoutParams(-1,-1));
            placeholder=Ui.text(activity,"",24,Ui.PURPLE,true);placeholder.setGravity(Gravity.CENTER);preview.addView(placeholder,new FrameLayout.LayoutParams(-1,-1));
            View shade=new View(activity);shade.setBackground(Ui.gradient(0x00111111,0xdd110d18,18,activity));preview.addView(shade,new FrameLayout.LayoutParams(-1,-1));
            caption=Ui.text(activity,"",17,Ui.TEXT,true);caption.setPadding(Ui.dp(activity,14),0,Ui.dp(activity,14),Ui.dp(activity,12));
            preview.addView(caption,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));card.addView(preview,Ui.lp(activity,-1,154));
            Ui.space(card,12);title=Ui.text(activity,"",14,Ui.TEXT,true);title.setMaxLines(2);card.addView(title);
            Ui.space(card,7);description=Ui.text(activity,"",11,Ui.PURPLE,false);card.addView(description);
            Ui.space(card,7);type=Ui.text(activity,"",10,Ui.MUTED,false);card.addView(type);
            Ui.space(card,9);state=Ui.text(activity,"",11,Ui.MUTED,false);card.addView(state);
            progress=new ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);
            LinearLayout.LayoutParams pp=Ui.lp(activity,-1,7);pp.topMargin=Ui.dp(activity,11);pp.bottomMargin=Ui.dp(activity,9);card.addView(progress,pp);
            size=Ui.text(activity,"",10,Ui.MUTED,false);card.addView(size);Ui.space(card,11);
            LinearLayout controls=Ui.row(activity);
            primary=Ui.button(activity,"",false,this::primaryAction);controls.addView(primary,new LinearLayout.LayoutParams(0,-2,1));
            save=Ui.button(activity,"Сохранить",false,()->{if(download!=null)OfflineExporter.saveWithPicker(activity,download);});
            controls.addView(save,new LinearLayout.LayoutParams(0,-2,1));
            controls.addView(Ui.iconButton(activity,"trash","Удалить загрузку",()->{if(download!=null)confirmDelete(download);}),Ui.lp(activity,44,44));
            card.addView(controls);
            preview.setOnClickListener(v->{if(download!=null&&download.state==Download.STATE_COMPLETED)Ui.openOffline(activity,download.request.id,anime,metadata.optDouble("episode",1));});
            card.setOnLongClickListener(v->{if(download!=null)actions(download);return true;});
        }
        void primaryAction() {
            if(download==null)return;
            if(download.state==Download.STATE_COMPLETED)Ui.openOffline(activity,download.request.id,anime,metadata.optDouble("episode",1));
            else if(download.state==Download.STATE_STOPPED)hub.resume(download.request.id);
            else if(download.state==Download.STATE_FAILED)hub.retry(download.request.id);
            else hub.pause(download.request.id);
            refreshSafe();
        }
        void bind(Download d) {
            download=d;metadata=DownloadHub.metadata(d);anime=Anime.from(metadata.optJSONObject("anime"));
            title.setText(Anime.valid(anime)?YoruBrain.title(anime):"Загрузка");
            double episode=metadata.optDouble("episode",1);int quality=metadata.optInt("quality");String voice=metadata.optString("voice","");
            description.setText("Серия "+Ui.number(episode)+" · "+(quality>0?quality+"p":"Оригинал")+(voice.isEmpty()?"":" · "+voice));
            caption.setText((d.state==Download.STATE_COMPLETED?"▶ ":"")+"Серия "+Ui.number(episode)+(d.state==Download.STATE_COMPLETED?" · готово офлайн":" · загрузка в YORU"));
            String url=ApiRepository.safeUrl(metadata.optString("episodePoster",metadata.optString("poster","")));
            if(url.isEmpty()&&Anime.valid(anime)&&!anime.screenshots.isEmpty())url=anime.screenshots.get(Math.abs((int)Math.floor(episode)-1)%anime.screenshots.size());
            String key=d.request.id+"|"+url;
            poster.setVisibility(url.isEmpty()?View.GONE:View.VISIBLE);placeholder.setVisibility(url.isEmpty()?View.VISIBLE:View.GONE);placeholder.setText("Серия\n"+Ui.number(episode));
            if(!key.equals(imageKey)){imageKey=key;poster.setTag(null);poster.setImageDrawable(null);if(!url.isEmpty())YoruApp.app().images.load(poster,url,key);}
            type.setText("Тип: "+OfflineExporter.format(d));
            String status=DownloadHub.status(d);
            if(d.state==Download.STATE_QUEUED&&YoruApp.app().store.wifiDownloads()&&YoruApp.app().traffic.metered())status="Ожидает Wi-Fi";
            state.setText(status);state.setTextColor(d.state==Download.STATE_FAILED?0xffe0a791:Ui.MUTED);
            boolean active=d.state==Download.STATE_DOWNLOADING||d.state==Download.STATE_QUEUED||d.state==Download.STATE_RESTARTING;
            progress.setVisibility(active?View.VISIBLE:View.GONE);float pct=d.getPercentDownloaded();progress.setIndeterminate(pct<0);progress.setProgress(pct<0?0:(int)pct);
            size.setText(Ui.bytes(d.getBytesDownloaded())+(d.contentLength>0?" / "+Ui.bytes(d.contentLength):""));
            primary.setText(d.state==Download.STATE_COMPLETED?"Смотреть":d.state==Download.STATE_STOPPED?"Продолжить":d.state==Download.STATE_FAILED?"Повторить":"Пауза");
            primary.setEnabled(d.state!=Download.STATE_REMOVING);
            save.setVisibility(d.state==Download.STATE_COMPLETED&&OfflineExporter.canExport(d)?View.VISIBLE:View.GONE);
        }
    }
}
